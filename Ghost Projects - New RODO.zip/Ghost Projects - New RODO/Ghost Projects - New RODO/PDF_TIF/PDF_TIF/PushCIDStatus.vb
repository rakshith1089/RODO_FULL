﻿Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Imports RestSharp

Module PushCIDStatus

    ''''''Private Sub Push_SAPID(ByVal URL As String, ByVal SAPID As String)
    ''''''    Dim client = New RestClient("http://localhost:52918/api/GetCID/InsertURL?URL=https://accentureindia-abacus-candidatedocuments-stage.s3.amazonaws.com/IDC/1010101_abcd.tif?AWSAccessKeyId=AKIAVKXJ3K7W7EB7BHUJ%26Expires=1778494812%26Signature=I5d9y23ixQIYNOb3v0UZMRLRQ74%3D&SAPID=11157145")
    ''''''    client.Timeout = -1
    ''''''    Dim request = New RestRequest(Method.PUT)
    ''''''    request.AddHeader("x-api-key", "AIzaSyB0e9xFwr0oTF56JFSjUft_R_iV0WkgfUM")
    ''''''    Dim response As IRestResponse = client.Execute(request)
    ''''''    Console.WriteLine(response.Content)
    ''''''End Sub

    Public Function GetCID_Details(ByVal SAPID As String) As DataTable
        Dim client = New RestClient("http://localhost:52918/api/FetchCID/GetCID_Details")
        client.Timeout = -1
        Cursor.Current = Cursors.WaitCursor
        Dim request = New RestRequest(Method.[GET])
        request.Timeout = 900000
        request.AddHeader("x-api-key", "AIzaSyB0e9xFwr0oTF56JFSjUft_R_iV0WkgfUM")
        request.AddHeader("content-type", "application/x-www-form-urlencoded")
        request.AddParameter("SAPID", SAPID)
        Dim response As IRestResponse = client.Execute(request)
        Dim response_data = response.Content
        Dim stuff = JsonConvert.DeserializeObject(response.Content)
        Dim dtResponse As String = stuff.ToString()
        Dim dtByteValur As Byte() = Convert.FromBase64String(dtResponse)
        Dim dt As DataTable = New DataTable()

        Using stream As MemoryStream = New MemoryStream(dtByteValur.ToArray())
            Dim bformatter As BinaryFormatter = New BinaryFormatter()
            stream.Seek(0, SeekOrigin.Begin)
            dt = CType(bformatter.Deserialize(stream), System.Data.DataTable)
        End Using

        Cursor.Current = Cursors.[Default]
        Return dt
        Cursor.Current = Cursors.[Default]
        Return dt
    End Function


    Public Function PushCID_Status(ByVal CID As String, ByVal Entity As String) As Boolean
        'Dim client = New RestClient("http://localhost:52918/api/GetCID/SetStatusClosed")

        '''Dim client = New RestClient("http://localhost:52918/api/GetCID/SetStatusClosed?CID=" & CID & "&Entity=" & Entity)
        Dim client = New RestClient("https://ssautomation.accenture.com/RODO_API/api/GetCID/SetStatusClosed?CID=" & CID & "&Entity=" & Entity)
        ''
        client.Timeout = -1
        Cursor.Current = Cursors.WaitCursor
        Dim request = New RestRequest(Method.[PUT])
        request.Timeout = 900000
        request.AddHeader("x-api-key", "AIzaSyB0e9xFwr0oTF56JFSjUft_R_iV0WkgfUM")
        request.AddHeader("content-type", "application/x-www-form-urlencoded")
        ''''request.AddParameter("CID", CID)
        ''''request.AddParameter("Entity", Entity)
        Dim response As IRestResponse = client.Execute(request)
        Dim status_code As String = response.StatusCode.ToString()
        If status_code = "OK" Then
            Cursor.Current = Cursors.[Default]
            Return True
        End If
        Cursor.Current = Cursors.[Default]
        Return False

    End Function

End Module
