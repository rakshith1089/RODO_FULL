﻿Imports Microsoft.Office.Interop

Module SaveResponses

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As System.Exception
            obj = Nothing
            MessageBox.Show("Exception Occured while releasing object " & ex.ToString())
        Finally
            GC.Collect()
        End Try
    End Sub
End Module
