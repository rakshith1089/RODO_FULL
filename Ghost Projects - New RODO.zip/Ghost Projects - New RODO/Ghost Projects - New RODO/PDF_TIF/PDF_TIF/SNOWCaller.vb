﻿Imports Newtonsoft.Json.Linq
Imports RestSharp

Module SNOWCaller

    Public Function generateToken()
        Dim client = New RestClient("https://login.microsoftonline.com/e0793d39-0939-496d-b129-198edd916feb/oauth2/token")
        client.Timeout = -1
        Dim request = New RestRequest(Method.POST)
        request.AddHeader("Content-Type", "application/x-www-form-urlencoded")
        request.AddHeader("Cookie", "fpc=Ajuz5jA3wq5FjWcvWOhr3LgIIu8NAQAAAA6-M9gOAAAA; stsservicecookie=estsfd; x-ms-gateway-slice=estsfd")
        request.AddParameter("client_id", "67e47eb3-1d92-4a69-8bd6-66dd32b2c98b")
        request.AddParameter("client_secret", "STIwJGEzQVVEMkZ1aTFCYQ==")
        request.AddParameter("Resource", "https://api.support.accenture.com/v2/support_ticket/")
        request.AddParameter("grant_type", "client_credentials")
        Dim response As IRestResponse = client.Execute(request)
        Dim response_data = JObject.Parse(response.Content)
        Dim accesstoken As String = response_data("access_token").ToString()
        Return accesstoken
    End Function
    Public Function snowreturn(ByVal URL, ByVal CIDEntity) As String
        Dim atoken As String = generateToken()
        ''''''TEST
        ''''''Dim client = New RestClient("https://api.support.ciotest.accenture.com/v2/support_ticket")
        '''
        Dim client = New RestClient("https://api.support.accenture.com/v2/support_ticket")
        client.Timeout = -1
        Dim request = New RestRequest(Method.PUT)
        request.AddHeader("authorizationtoken", "Bearer " & atoken)
        request.AddHeader("catalogitem", "4939c26f1b0c38142196a6c6bc4bcb4a")
        'TEST
        'request.AddHeader("x-api-key", "bQja77sUdk2WidmMsqIIXaka1OVYxizr3q5uVOLm")
        'STAGE
        'request.AddHeader("x-api-key", "ngOhnrBWzwskLVpL9Qeu8BiGCUPwhZB3vSD12nh0")
        'PROD
        request.AddHeader("x-api-key", "pldGJakJ4k5FiEO6IqNTq48R4knxNA0b2ZEPKCmK")
        request.AddHeader("Content-Type", "application/json")
        request.AddParameter("application/json", "{""body"":[" & vbCrLf & "    {" & vbCrLf & "        ""requested_for"": ""ads.lmallesh""," & vbCrLf & "        ""correlation_id"": """"," & vbCrLf & "        ""column_name"": ""u_cidentity""," & vbCrLf & "        ""column_value"": " & CIDEntity & "," & vbCrLf & "        ""variables"": {" & vbCrLf & "            " & vbCrLf & "            ""u_url"": " & URL & "" & vbCrLf & "        }," & vbCrLf & "        ""attachments"": [" & vbCrLf & "            {" & vbCrLf & "                ""payload"": """"," & vbCrLf & "                ""file_name"": """"," & vbCrLf & "                ""content_type"": """"," & vbCrLf & "                ""encoding"": """"" & vbCrLf & "            }" & vbCrLf & "        ]" & vbCrLf & "    }" & vbCrLf & "]" & vbCrLf & "}" & vbCrLf, ParameterType.RequestBody)
        Dim response As IRestResponse = client.Execute(request)
        Console.WriteLine(response.Content)
        Return (response.Content)
    End Function
End Module
