﻿Imports System.IO
Imports System.Threading
Imports System.Net
Imports System.Text
Imports System.Linq
Imports System.Text.RegularExpressions

Public Class Home
    Public Result As String()
    Dim Entity As String
    Public CIDEntity As String
    Public CID_ As String
    Public date_n_Time As String

    Private Sub Home_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Remove insecure protocols (SSL3, TLS 1.0, TLS 1.1)
        ServicePointManager.SecurityProtocol = ServicePointManager.SecurityProtocol And SecurityProtocolType.Ssl3
        ServicePointManager.SecurityProtocol = ServicePointManager.SecurityProtocol And SecurityProtocolType.Tls
        ServicePointManager.SecurityProtocol = ServicePointManager.SecurityProtocol And SecurityProtocolType.Tls11
        'Add TLS 1.2
        ServicePointManager.SecurityProtocol = ServicePointManager.SecurityProtocol Or SecurityProtocolType.Tls12


        Dim Main_Folder_Path As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\BGC_Snow_Downloads\"
        Dim counter As String() = Directory.GetFiles(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\Pending_to_Tiff\", "*.pdf", SearchOption.TopDirectoryOnly)
        Dim fileName As String = ""
        Dim PdfFilePath As String = ""
        Dim result_count As Integer = counter.Length
        Dim TiffFilePath As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\Converted_Tiff\"
        Dim TiffFilePathFinal As String = ""
        Dim Start_Time As String = DateTime.Now.ToString()
        Dim Count As Integer = counter.Count
        For i As Integer = 0 To CStr(counter.Count) - 1

            PdfFilePath = counter(i)
            Dim FileInfo As New FileInfo(PdfFilePath)
            fileName = Path.GetFileNameWithoutExtension(FileInfo.ToString)
            TiffFilePathFinal = TiffFilePath + fileName + "_Background_" + ddmmyy() + ".tif"
            'Filename_acounso = "" & txt_SAP_ID.Text & "_" & Aconso & "_" & ddmmyy() & ""

            Dim Args() As String = {"-q", "-dNOPAUSE", "-dBATCH", "-dSAFER",
                   "-sDEVICE=tiffg4", "-r800", "-dDownScaleFactor=6", "-dTextAlphaBits=4",
                   "-dGraphicsAlphaBits=4", "-sPAPERSIZE=letter",
                   "-sOutputFile=" & TiffFilePathFinal, PdfFilePath}
            RunGS(Args)
            Result = IO.Directory.GetDirectories(Main_Folder_Path, "*_" & fileName)
            CIDEntity = Result(0).Substring(Result(0).LastIndexOf("\") + 1)
            Result = CIDEntity.Split("_")
            CID_ = Result(0)
            Entity = Result(1)
            If Entity = "BPO" Then
                Entity = "AO"
            End If
            CIDEntity = CID_ & Entity
            My.Computer.FileSystem.DeleteFile(PdfFilePath)
            Dim aws3url As String = ""
            aws3url = UploadFile(TiffFilePathFinal, Entity)
            snowreturn(aws3url, CIDEntity)
            ''CID_ = "CData14"
            ''Entity = "IDC"
            PushCID_Status(CID_, Entity)
        Next
        Dim End_Time As String = DateTime.Now.ToString()
        ' Api("RoDo_Tiff", Start_Time, End_Time, Count)
        Me.Close()
    End Sub

    Public Function ddmmyy() As String
        Dim ddd As Date
        Dim m, d, yy, h, mn1, s, ms1, ms2, ms3 As Integer
        Dim mm, dd, hh, mn, ss, ms As String

        ddd = Now
        m = ddd.Month
        If m < 10 Then
            mm = "0" & m
        Else
            mm = m
        End If

        d = ddd.Day
        If d < 10 Then
            dd = "0" & d
        Else
            dd = d
        End If
        yy = ddd.Year

        h = ddd.Hour
        If h = 0 Then
            hh = "00"
        ElseIf h < 10 Then
            hh = "0" & h
        Else
            hh = h
        End If


        mn1 = ddd.Minute
        If mn1 = 0 Then
            mn = "00"
        ElseIf mn1 < 10 Then
            mn = "0" & mn1
        Else
            mn = mn1
        End If

        s = ddd.Second
        If s = 0 Then
            ss = "00"
        ElseIf s < 10 Then
            ss = "0" & s
        Else
            ss = s
        End If

        ms1 = ddd.Millisecond
        If ms1 = 0 Then
            ms = "00"

        ElseIf ms1 < 10 Then
            ms = "0" & ms1

        ElseIf ms1 > 100 Then
            ms2 = ms1 Mod 100
            ms3 = ms2

            If ms3 = 0 Then
                ms = "00"
            ElseIf ms3 < 10 Then
                ms = "0" & ms3
            Else
                ms = ms3
            End If

        Else
            ms = ms1
        End If

        date_n_Time = mm & dd & yy & "_" & hh & mn & ss & ms
        Return date_n_Time
    End Function

    Public Sub Api(ByVal toolname As String, ByVal Start_Time As String, ByVal End_Time As String, ByVal Count As Integer)



        Dim request = CType(WebRequest.Create("https://ssautomation.accenture.com/e_travel_api/api/values"), HttpWebRequest)
        Dim postData = "tool_name=" & toolname & "&start_time=" & Start_Time & "&end_time=" & End_Time & "&total_time=" & (Convert.ToDateTime(End_Time) - Convert.ToDateTime(Start_Time)).ToString() & "&count=" & Count & "&submitted_by=" + Environment.UserName & "&uploaded_date=" + DateTime.Now.Date & ""
        Dim data = Encoding.ASCII.GetBytes(postData)
        request.Method = "POST"
        request.ContentType = "application/x-www-form-urlencoded"
        request.Headers.Add("x-api-key", "F1EEA6B6-2FBD-4887-96E2-07024C37BC6F")
        request.ContentLength = data.Length

        Using stream = request.GetRequestStream()
            stream.Write(data, 0, data.Length)
        End Using

        Dim response = CType(request.GetResponse(), HttpWebResponse)
        Dim responseString = New StreamReader(response.GetResponseStream()).ReadToEnd()
    End Sub

End Class
