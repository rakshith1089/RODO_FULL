﻿Imports System.IO
Imports Amazon.S3
Imports Amazon.S3.Model

Module AmazonUploader
    'Private bucketName As String = "accentureindia-abacus-candidatedocuments-stage"
    Private bucketName As String = "accentureindia-abacus-candidatedocuments-production"
    Private keyName As String

    Public Function UploadFile(ByVal filePath As String, ByVal Entity As String) As String
        Dim filename As String = Path.GetFileName(filePath)
        Dim client = New AmazonS3Client(Amazon.RegionEndpoint.USEast1)


        keyName = Entity & "/" & filename

        Try
            Dim putRequest As PutObjectRequest = New PutObjectRequest With {
                .BucketName = bucketName,
                .Key = keyName,
                .FilePath = filePath,
                .ContentType = "text/plain"
            }
            Dim response As PutObjectResponse = client.PutObject(putRequest)
            Dim uploadedFileUrl As String = client.GetPreSignedURL(New GetPreSignedUrlRequest() With {
                .BucketName = bucketName,
                .Key = keyName,
                .Expires = DateTime.Now.AddYears(5)
            })
            Console.WriteLine("File download URL: {0}", uploadedFileUrl)
            Return uploadedFileUrl
        Catch amazonS3Exception As AmazonS3Exception

            If amazonS3Exception.ErrorCode IsNot Nothing AndAlso (amazonS3Exception.ErrorCode.Equals("InvalidAccessKeyId") OrElse amazonS3Exception.ErrorCode.Equals("InvalidSecurity")) Then
                Throw New Exception("Check the provided AWS Credentials.")
            Else
                Throw New Exception("Error occurred: " & amazonS3Exception.Message)
            End If
        End Try
    End Function
End Module
