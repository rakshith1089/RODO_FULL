﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Snow_Tool
{
    class GhoxtScript
    {
        [DllImport("gsdll32.dll", EntryPoint = "gsapi_new_instance")]
        private static extern int gsapi_new_instance(IntPtr pinstance, IntPtr caller_handle);

        [DllImport("gsdll32.dll", EntryPoint = "gsapi_init_with_args")]
        private static extern int gsapi_init_with_args(IntPtr instance, int argc, string[] argv);

        [DllImport("gsdll32.dll", EntryPoint = "gsapi_exit")]
        private static extern int gsapi_exit(IntPtr instance);

        [DllImport("gsdll32.dll", EntryPoint = "gsapi_delete_instance")]
        private static extern void gsapi_delete_instance(IntPtr instance);

        public static bool RunGS(string[] Args)
        {
            IntPtr InstanceHndl = new IntPtr(0);
            IntPtr InstanceHnd2 = new IntPtr(0);
            int NumArgs;
            NumArgs = Args.Count();
            var oldArgs = Args;
            Args = new string[NumArgs + 1];

            if (oldArgs != null)
                Array.Copy(oldArgs, Args, Math.Min(NumArgs + 1, oldArgs.Length));
            System.Array.Copy(Args, 0, Args, 1, NumArgs);

            // --- Start a new Ghostscript instance
            try
            {
                if (gsapi_new_instance(InstanceHndl, InstanceHnd2) != 0)
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            try
            {
                gsapi_init_with_args(InstanceHndl, NumArgs + 1, Args);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            gsapi_exit(InstanceHndl);

            gsapi_delete_instance(InstanceHndl);

            return true;
        }

    }
}
