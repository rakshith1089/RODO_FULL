﻿namespace Snow_Tool
{
    partial class PendingCIDList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPanel = new System.Windows.Forms.Button();
            this.Label2 = new System.Windows.Forms.Label();
            this.cbo_CIDCount = new System.Windows.Forms.ComboBox();
            this.lbl_TotalCIDs = new System.Windows.Forms.Label();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.btn_Convert = new System.Windows.Forms.Button();
            this.dgv_PendingList = new System.Windows.Forms.DataGridView();
            this.Label1 = new System.Windows.Forms.Label();
            this.btn_SearchPendingCIDs = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PendingList)).BeginInit();
            this.SuspendLayout();
            // 
            // btnPanel
            // 
            this.btnPanel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPanel.Location = new System.Drawing.Point(4, 3);
            this.btnPanel.Name = "btnPanel";
            this.btnPanel.Size = new System.Drawing.Size(1232, 33);
            this.btnPanel.TabIndex = 11;
            this.btnPanel.Text = "Details";
            this.btnPanel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPanel.UseVisualStyleBackColor = true;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(162, 48);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(140, 17);
            this.Label2.TabIndex = 26;
            this.Label2.Text = "CID Count to Convert";
            // 
            // cbo_CIDCount
            // 
            this.cbo_CIDCount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(157)))), ((int)(((byte)(68)))));
            this.cbo_CIDCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbo_CIDCount.FormattingEnabled = true;
            this.cbo_CIDCount.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "5",
            "10",
            "20",
            "30",
            "50",
            "100",
            "200",
            "500"});
            this.cbo_CIDCount.Location = new System.Drawing.Point(165, 69);
            this.cbo_CIDCount.Name = "cbo_CIDCount";
            this.cbo_CIDCount.Size = new System.Drawing.Size(137, 37);
            this.cbo_CIDCount.TabIndex = 25;
            // 
            // lbl_TotalCIDs
            // 
            this.lbl_TotalCIDs.AutoSize = true;
            this.lbl_TotalCIDs.Location = new System.Drawing.Point(1190, 112);
            this.lbl_TotalCIDs.Name = "lbl_TotalCIDs";
            this.lbl_TotalCIDs.Size = new System.Drawing.Size(40, 17);
            this.lbl_TotalCIDs.TabIndex = 24;
            this.lbl_TotalCIDs.Text = "Total";
            // 
            // btn_Clear
            // 
            this.btn_Clear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(157)))), ((int)(((byte)(68)))));
            this.btn_Clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Clear.ForeColor = System.Drawing.Color.White;
            this.btn_Clear.Location = new System.Drawing.Point(1095, 536);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(137, 39);
            this.btn_Clear.TabIndex = 22;
            this.btn_Clear.Text = "Clear";
            this.btn_Clear.UseVisualStyleBackColor = false;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // btn_Convert
            // 
            this.btn_Convert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(157)))), ((int)(((byte)(68)))));
            this.btn_Convert.Enabled = false;
            this.btn_Convert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Convert.ForeColor = System.Drawing.Color.White;
            this.btn_Convert.Location = new System.Drawing.Point(952, 536);
            this.btn_Convert.Name = "btn_Convert";
            this.btn_Convert.Size = new System.Drawing.Size(137, 39);
            this.btn_Convert.TabIndex = 23;
            this.btn_Convert.Text = "Convert";
            this.btn_Convert.UseVisualStyleBackColor = false;
            this.btn_Convert.Click += new System.EventHandler(this.btn_Convert_Click);
            // 
            // dgv_PendingList
            // 
            this.dgv_PendingList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_PendingList.Location = new System.Drawing.Point(12, 132);
            this.dgv_PendingList.Name = "dgv_PendingList";
            this.dgv_PendingList.RowTemplate.Height = 24;
            this.dgv_PendingList.Size = new System.Drawing.Size(1218, 398);
            this.dgv_PendingList.TabIndex = 21;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(9, 48);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(93, 17);
            this.Label1.TabIndex = 20;
            this.Label1.Text = "Pending CIDs";
            // 
            // btn_SearchPendingCIDs
            // 
            this.btn_SearchPendingCIDs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(157)))), ((int)(((byte)(68)))));
            this.btn_SearchPendingCIDs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_SearchPendingCIDs.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.btn_SearchPendingCIDs.ForeColor = System.Drawing.Color.White;
            this.btn_SearchPendingCIDs.Location = new System.Drawing.Point(9, 68);
            this.btn_SearchPendingCIDs.Name = "btn_SearchPendingCIDs";
            this.btn_SearchPendingCIDs.Size = new System.Drawing.Size(137, 39);
            this.btn_SearchPendingCIDs.TabIndex = 19;
            this.btn_SearchPendingCIDs.Text = "Search";
            this.btn_SearchPendingCIDs.UseVisualStyleBackColor = false;
            this.btn_SearchPendingCIDs.Click += new System.EventHandler(this.btn_SearchPendingCIDs_Click);
            // 
            // PendingCIDList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1250, 583);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.cbo_CIDCount);
            this.Controls.Add(this.lbl_TotalCIDs);
            this.Controls.Add(this.btn_Clear);
            this.Controls.Add(this.btn_Convert);
            this.Controls.Add(this.dgv_PendingList);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.btn_SearchPendingCIDs);
            this.Controls.Add(this.btnPanel);
            this.Name = "PendingCIDList";
            this.Text = "PendingCIDList";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PendingCIDList_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PendingList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button btnPanel;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.ComboBox cbo_CIDCount;
        internal System.Windows.Forms.Label lbl_TotalCIDs;
        internal System.Windows.Forms.Button btn_Clear;
        internal System.Windows.Forms.Button btn_Convert;
        internal System.Windows.Forms.DataGridView dgv_PendingList;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Button btn_SearchPendingCIDs;
    }
}