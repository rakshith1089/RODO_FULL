﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Snow_Tool
{
    class GlobalVariable
    {
        public static DataTable GlobalDataTable;
    }
}
