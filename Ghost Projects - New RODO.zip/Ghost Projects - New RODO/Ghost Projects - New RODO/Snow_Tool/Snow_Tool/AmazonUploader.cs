﻿using Amazon.S3;
using Amazon.S3.Model;
using System;
using System.IO;

namespace Snow_Tool
{
    class AmazonUploader
    {
       
        private string bucketName = "accentureindia-abacus-candidatedocuments-stage";
        private string keyName;//"IDC/hr_case.pdf";
        //private string filePath = "C:\\Users\\rakshith.r.bhat\\Downloads\\hr_case.pdf";

        public string UploadFile(string filePath,string Entity)
        {
            string filename = Path.GetFileName(filePath);
            var client = new AmazonS3Client(Amazon.RegionEndpoint.USEast1);
            keyName = Entity + "/" + filename;
            try
            {
                PutObjectRequest putRequest = new PutObjectRequest
                {
                    BucketName = bucketName,
                    Key = keyName,
                    FilePath = filePath,
                    ContentType = "text/plain"
                };

                PutObjectResponse response = client.PutObject(putRequest);
                // Share the uploaded file and get a download URL
            string uploadedFileUrl = client.GetPreSignedURL(new GetPreSignedUrlRequest()
            {
                BucketName = bucketName,
                Key = keyName,
                Expires = DateTime.Now.AddYears(5)
            });
                Console.WriteLine("File download URL: {0}", uploadedFileUrl);
                return uploadedFileUrl;
            }
            catch (AmazonS3Exception amazonS3Exception)
            {
                if (amazonS3Exception.ErrorCode != null &&
                    (amazonS3Exception.ErrorCode.Equals("InvalidAccessKeyId")
                    ||
                    amazonS3Exception.ErrorCode.Equals("InvalidSecurity")))
                {
                    throw new Exception("Check the provided AWS Credentials.");
                }
                else
                {
                    throw new Exception("Error occurred: " + amazonS3Exception.Message);
                }
            }
        }
    }
}
