﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snow_Tool
{
    class SNOWCaller
    {
        public string snowreturn()
        {
            //////////var client = new RestClient("https://api.support.ciodev.accenture.com/v2/opsdev/support_ticket");
            //////////client.Timeout = -1;
            //////////var request = new RestRequest(Method.POST);
            //////////request.AddHeader("authorizationtoken", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyIsImtpZCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyJ9.eyJhdWQiOiJodHRwczovL2FwaS5zdXBwb3J0LmNpb3N0YWdlLmFjY2VudHVyZS5jb20vdjIvc3VwcG9ydF90aWNrZXQvIiwiaXNzIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyLyIsImlhdCI6MTYyMDgwMDc0NSwibmJmIjoxNjIwODAwNzQ1LCJleHAiOjE2MjA4MDQ2NDUsImFpbyI6IkUyWmdZQkQ4WTk2MWVMZS9uSDZuamVVYjBVOStBQT09IiwiYXBwaWQiOiI2N2U0N2ViMy0xZDkyLTRhNjktOGJkNi02NmRkMzJiMmM5OGIiLCJhcHBpZGFjciI6IjEiLCJpZHAiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwib2lkIjoiYjI3YTY2MjYtNjAwMC00ODljLWFiNTQtYTJjNzEzMDQ4NzMyIiwicmgiOiIwLkFTWUFEaDBoODFzU3cwS0cyeklyR2FaYUlyTi01R2VTSFdsS2k5Wm0zVEt5eVlzbUFBQS4iLCJyb2xlcyI6WyJyZWFkX3NuZmFfdW5pZmllZGdhdGV3YXkiXSwic3ViIjoiYjI3YTY2MjYtNjAwMC00ODljLWFiNTQtYTJjNzEzMDQ4NzMyIiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidXRpIjoiNFI0OEQtY2hWa1N4T19wNnpESkVBQSIsInZlciI6IjEuMCJ9.OksODLrpNbdZTlRX1DDAgjExw-zJv6KNY1SvmGmtzSjtynuH_6eylMZHNp3XsDzVmla4zHptlsLZnubmX2x7vePaiiGqfJlOjoNHtN8wjMGjBQRxrw6eVeYY4M6piPpLFM6cyoelvbFi2YlegkLt1RcjtLLQ1YKVcjXPLRLeM2iqHdz5iKJQmcciINh1-4hoQgGjjYy_91hHF37Yf1jnc6ajtM_3wm1KZzOhYjLu4Nx3LVop3yK1sZpv44vGlM66DylOSn-s4U6YcadF886fLaPqK8DsitjMONjvNlOEtRRGyWzEsWoLG0kybMsZ2KT0_gVVcXJFKhXLmQYfeZgCrA");
            //////////request.AddHeader("catalogitem", "aafe758b87dba410f380ca6acebb354d");
            //////////request.AddHeader("x-api-key", "HImrEKGXzE1UiFvqteI2H5K7lHHS5PpG7ZlB333j");
            //////////request.AddHeader("Content-Type", "application/json");
            //////////request.AddParameter("application/json", "{\"body\":[ {\r\n\"requested_for\": \"ads.rbhat\",\r\n\"correlation_id\": \"5156_data_service_test\",\r\n\"record_number\": \"\",\r\n\"variables\": {\r\n\"cid_pushedon\": \"11-05-2020\",\r\n\"type\": \"\",\r\n\"cid_pushedby\": \"ads.rbhat\",\r\n\"entity\": \"IDC\",\r\n\"url\": \"https://accentureindia-abacus-candidatedocuments-stage.s3.amazonaws.com/IDC/1010101_abcd.tif?AWSAccessKeyId=AKIAVKXJ3K7W7EB7BHUJ&Expires=1778494812&Signature=I5d9y23ixQIYNOb3v0UZMRLRQ74%3D\",\r\n\"cid\": \"C777\"\r\n},\r\n\"attachments\": [\r\n{\r\n\"payload\": \"\",\r\n\"file_name\": \"\",\r\n\"content_type\": \"\",\r\n\"encoding\": \"\"\r\n}\r\n]\r\n}\r\n]\r\n}", ParameterType.RequestBody);
            //////////IRestResponse response = client.Execute(request);
            //////////return(response.Content);

            var client = new RestClient("https://api.support.ciodev.accenture.com/v2/opsdev/support_ticket");
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
            request.AddHeader("authorizationtoken", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyIsImtpZCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyJ9.eyJhdWQiOiJodHRwczovL2FwaS5zdXBwb3J0LmNpb3N0YWdlLmFjY2VudHVyZS5jb20vdjIvc3VwcG9ydF90aWNrZXQvIiwiaXNzIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyLyIsImlhdCI6MTYyMTIxNDY5MSwibmJmIjoxNjIxMjE0NjkxLCJleHAiOjE2MjEyMTg1OTEsImFpbyI6IkUyWmdZUGhxcEhreXVzRDh2VXZGZ3A4RnN6M3pBQT09IiwiYXBwaWQiOiI2N2U0N2ViMy0xZDkyLTRhNjktOGJkNi02NmRkMzJiMmM5OGIiLCJhcHBpZGFjciI6IjEiLCJpZHAiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mMzIxMWQwZS0xMjViLTQyYzMtODZkYi0zMjJiMTlhNjVhMjIvIiwib2lkIjoiYjI3YTY2MjYtNjAwMC00ODljLWFiNTQtYTJjNzEzMDQ4NzMyIiwicmgiOiIwLkFTWUFEaDBoODFzU3cwS0cyeklyR2FaYUlyTi01R2VTSFdsS2k5Wm0zVEt5eVlzbUFBQS4iLCJyb2xlcyI6WyJyZWFkX3NuZmFfdW5pZmllZGdhdGV3YXkiXSwic3ViIjoiYjI3YTY2MjYtNjAwMC00ODljLWFiNTQtYTJjNzEzMDQ4NzMyIiwidGlkIjoiZjMyMTFkMGUtMTI1Yi00MmMzLTg2ZGItMzIyYjE5YTY1YTIyIiwidXRpIjoiaWxUYW55Zk1Oa0t1OXlYaUthVXdBQSIsInZlciI6IjEuMCJ9.Ju378w8wCUMnDoOaCbRjMqp7uN836zGkKbfRyNke7citOVwikNRAsPCrDWnY6p04cKY8OjbXXJQPxM7pH1IdpsmxOUkRjoE9dfMFw6mpQAW13yj9NBoxX8Eyrh8NHkOM_U42S_ufOJhCGDATCVlkzUS0MyomK14vUN8fQkgtNynwJ3mZtGPQvWlWxY6AR-PYP01qtiN11YTTZ4iraZohTqYEdoSMq83rONalA7Kkfyxc3ombQuP8cZyKzG8Yao9i2D_h_71KsBuu7GSUaLqHjDBW06A9P-txHQCn9m2L3Zz6RQDpv7M7Yd8x5KP2KOic6s-X9Vgw4xw7OhFO3qioQg");
            request.AddHeader("catalogitem", "182c80b5dbccf49834f0d48a489619cd");
            request.AddHeader("x-api-key", "HImrEKGXzE1UiFvqteI2H5K7lHHS5PpG7ZlB333j");
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("application/json", "{\"body\":[ {\r\n\"requested_for\": \"ads.rbhat\",\r\n\"correlation_id\": \"5156_data_service_test\",\r\n\"column_name\": \"\",\r\n\"column_value\": \"\",\r\n// \"record_number\": \"\",\r\n\"variables\": {\r\n\"u_cid_pushedby\": \"ads.rbhat\",\r\n\"u_cid_pushedon\": \"11-05-2020\",\r\n\"u_entity\": \"IDC\",\r\n\"u_url\": \"https://accentureindia-abacus-candidatedocuments-stage.s3.amazonaws.com/IDC/1010101_abcd.tif?AWSAccessKeyId=AKIAVKXJ3K7W7EB7BHUJ&Expires=1778494812&Signature=I5d9y23ixQIYNOb3v0UZMRLRQ74%3D\",  \r\n\"u_type\": \"\",\r\n\"u_cid\": \"C777\"\r\n},\r\n\"attachments\": [\r\n{\r\n\"payload\": \"\",\r\n\"file_name\": \"\",\r\n\"content_type\": \"\",\r\n\"encoding\": \"\"\r\n}\r\n]\r\n}\r\n]\r\n}", ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            return (response.Content);
        }
    }
}
