﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Snow_Tool
{
    class classPendingCIDs
    {
        public DataTable func_getPendingCIDList(int NofCIDs, string ClientParameter)
        {
            Cursor.Current = Cursors.WaitCursor;
            var clnt = ClientParameter.ToString();
            var Client = new RestClient(clnt);
            var request = new RestRequest(Method.GET);
            request.Timeout = 900000;
            request.AddHeader("x-api-key", "AIzaSyB0e9xFwr0oTF56JFSjUft_R_iV0WkgfUM");
            request.AddHeader("content-type", "application/x-www-form-urlencoded");
            request.AddParameter("NofCIDs", NofCIDs);
            IRestResponse response = Client.Execute(request);

            var response_data = response.Content;

               dynamic stuff = JsonConvert.DeserializeObject(response.Content);

            //var response_data = stuff.Pending_List;
            //string status_code = response.StatusCode.ToString();
            //if (status_code == "InternalServerError")
            //    return null;

            // string dtResponse = response_data.GetValue("Pending_List").ToString() ;            
            string dtResponse = stuff.ToString();
             byte[] dtByteValur = Convert.FromBase64String(dtResponse);
            DataTable dt=new DataTable();

            using (MemoryStream stream = new MemoryStream(dtByteValur.ToArray()))
            {
                BinaryFormatter bformatter = new BinaryFormatter();
                stream.Seek(0, SeekOrigin.Begin);
                dt = (System.Data.DataTable)bformatter.Deserialize(stream);
            }

            //if (status_code == "Created")
            //{
            //bool error_status = Convert.ToBoolean(response_data("error"));
            // Dim response_if_no_case = response_data("response").ToString()

            //if (!error_status)
            //{
            //    // Dim b64_response As String = response_data("response").ToString()
            //    try
            //    {
            Cursor.Current = Cursors.Default;

                return dt;
                //    }
                //    catch
                //    {
                //    }
                //    Cursor.Current = Cursors.Default;
                //}
                //else
                //{
                //    // MessageBox.Show(response_if_no_case)
                //    return null;
                //    Cursor.Current = Cursors.Default;
                //}
            //}
            Cursor.Current = Cursors.Default;
            return dt;
        }
    }
}
