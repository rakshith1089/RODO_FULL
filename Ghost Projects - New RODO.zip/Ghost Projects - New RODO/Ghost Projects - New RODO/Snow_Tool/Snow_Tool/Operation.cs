﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Threading;
using System.Windows.Forms;
using OpenQA.Selenium.IE;
using System.Collections.ObjectModel;
using System.Diagnostics;
using OpenQA.Selenium.Interactions;
using System.IO;
using iTextSharp.text.pdf;
using iTextSharp.text;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.Net;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using RestSharp;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Model;
using System.Data;

namespace Snow_Tool
{
    class Operation
    {



        // private static InternetExplorerDriver driver;
        private static ChromeDriver driver;
        /// private static EdgeDriver driver;
        private static By by;
        //private static string URLIE = "https://support-sbox12.accenture.com/";//"https://support.accenture.com/bgc_hr/";
        ////////////////////////////////////////private static string URLChrome = "https://support-sbox7.accenture.com/";//"https://support.accenture.com/";        ////https://support-sbox12.accenture.com        

        //TESTING
        //private static string URLChrome = "https://support-test.accenture.com/nav_to.do?uri=%2Fhome.do%3F";

        //STAGING
        //private static string URLChrome = "https://support-stage.accenture.com/nav_to.do?uri=%2Fhome.do%3F%3D";

        private static string URLChrome = "https://support.accenture.com/bgc_hr/";
            //ENDS

        private static string IE_DRIVER_PATH = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\Drivers\";
        private static string Chrome_DRIVER_PATH = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\Drivers\";
        private static string Download_Folder_Path = @"C:\Users\" + Environment.UserName + @"\Downloads\";
        private static string Main_Folder_Path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\BGC_Snow_Downloads\";
        private static string Signature_Folder_Path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\BGC_Snow_Downloads_Signature\";
        private static string Pending_Folder_Path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\Pending_to_Tiff\";
        private static string Convert_Folder_Path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\Converted_Tiff\";
        public static int firstPopup = 0;
        private static int rowCount, numberOfPages;
        private static Boolean hasSubFolder = false;
        private static string PasswordPDF = "";

        private const int BUFFER_SIZE = 1024 * 1024;

        public static void ExecuteOperation()
        {
            

            if (!Directory.Exists(Main_Folder_Path))
            {
                Directory.CreateDirectory(Main_Folder_Path);
            }
            if (!Directory.Exists(Pending_Folder_Path))
            {
                Directory.CreateDirectory(Pending_Folder_Path);
            }
            if (!Directory.Exists(Convert_Folder_Path))
            {
                Directory.CreateDirectory(Convert_Folder_Path);
            }
            if (!Directory.Exists(Signature_Folder_Path))
            {
                Directory.CreateDirectory(Signature_Folder_Path);
            }    


            //IEInitializeDriver(); 
            Chrome_InitializeDriver();
            // Edge_InitializeDriver();


            by = By.Id("i0116");
            WaitForElementLoad(by, 120);
            driver.FindElement(by).SendKeys("rakshith.r.bhat@ds.dev.accenture.com");


            by = By.Id("idSIButton9");
            WaitForElementLoad(by, 120);
            driver.FindElement(by).Click();

            by = By.Id("passwordInput");
            WaitForElementLoad(by, 120);
            driver.FindElement(by).SendKeys("2508Raks%%");

            Thread.Sleep(60000);

            //driver.Navigate().GoToUrl(URLIE+"bgc_hr/");

            //driver.Navigate().GoToUrl(URLChrome + "bgc_hr/bgc_index");

            //Commneted for Staging
            ///driver.Navigate().GoToUrl(URLChrome + "bgc_hr/");
            //Commnets end


            //driver.Navigate().GoToUrl("https://support-sbox12.accenture.com/hr_case.do?sys_id=00920ca11bfaec1cd4e363d5ec4bcb48&sysparm_record_list=u_bgc_record.u_cidSTARTSWITHC777%5eORDERBYnumber&sysparm_record_row=1&sysparm_record_rows=4&sysparm_record_target=hr_case&sysparm_view=bgc_case&sysparm_view_forced=true");
            string Start_Time = DateTime.Now.ToString();
            ////////DataRow workRow = GlobalVariable.GlobalDataTable.NewRow();
            ////////workRow["CID"] = "C507012";
            ////////workRow[1] = "C507012";

            ////////workRow["Entity"] = "BPO";
            ////////workRow[1] = "BPO";

            rowCount = GlobalVariable.GlobalDataTable.Rows.Count;
            for (int i = 0; i < rowCount; i++)
            {
                Download_Doc1(i);
            }
            string End_Time = DateTime.Now.ToString();
            //Api("RoDo_Download", Start_Time, End_Time);
            Rearrange_Docs();
            Merge_Docs();
            Convert_Tiff();
        }

        private static void WaitForElementLoad(By by, int seconds)
        {
            new WebDriverWait(driver, TimeSpan.FromSeconds(seconds)).Until(ExpectedConditions.ElementExists(by));
            new WebDriverWait(driver, TimeSpan.FromSeconds(seconds)).Until(ExpectedConditions.ElementIsVisible(by));
        }

        //IE
        //private static void IEInitializeDriver()
        //{
        //    InternetExplorerOptions options = new InternetExplorerOptions();
        //    options.EnableNativeEvents = false;
        //    options.IntroduceInstabilityByIgnoringProtectedModeSettings = true;
        //    options.EnablePersistentHover = true;
        //    options.IgnoreZoomLevel = false;
        //    options.PageLoadStrategy = InternetExplorerPageLoadStrategy.Eager;





        //    driver = new InternetExplorerDriver(IE_DRIVER_PATH, options);
        //    options.ForceCreateProcessApi = true;
        //    options.BrowserCommandLineArguments.Insert(0, "-private");


        ////driver.Manage().Timeouts().SetPageLoadTimeout(TimeSpan.FromSeconds(120));
        ////driver.Manage().Timeouts().SetScriptTimeout(TimeSpan.FromSeconds(120));
        ////driver.Manage().Window.Maximize();
        ////driver.Navigate().GoToUrl(URLIE);
        // }

        //Chrome
        private static void Chrome_InitializeDriver()
        {
             driver = new ChromeDriver(Chrome_DRIVER_PATH);

            //STAGE AND TEST
            ////ChromeOptions options = new ChromeOptions();
            ////options.AddArguments("--incognito");
            ////driver = new ChromeDriver(Chrome_DRIVER_PATH, options);


            driver.Manage().Timeouts().SetPageLoadTimeout(TimeSpan.FromSeconds(120));
            driver.Manage().Timeouts().SetScriptTimeout(TimeSpan.FromSeconds(120));
            driver.Navigate().GoToUrl(URLChrome);
            driver.Manage().Window.Maximize();
        }

        //Edge
        ////////private static void Edge_InitializeDriver()
        ////////{
        ////////    EdgeOptions options = new EdgeOptions();
        ////////    options.PageLoadStrategy = EdgePageLoadStrategy.Eager;
        ////////    driver = new EdgeDriver(Chrome_DRIVER_PATH, options);
        ////////    driver.Manage().Timeouts().SetPageLoadTimeout(TimeSpan.FromSeconds(120));
        ////////    driver.Manage().Timeouts().SetScriptTimeout(TimeSpan.FromSeconds(120));
        ////////    driver.Navigate().GoToUrl(URLChrome);
        ////////    driver.Manage().Window.Maximize();
        ////////}

        //IE Code

        //private static void Download_Doc(int data)
        //{
        //    try
        //    {
        //        if (data == 0)
        //        {
        //            by = By.XPath("//*[@id='ess_search_input']");
        //            WaitForElementLoad(by, 120);

        //            driver.Navigate().GoToUrl("https://support.accenture.com/bgc_hr/#q=" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString());
        //            driver.Navigate().Refresh();
        //        }
        //        else
        //        {
        //            driver.Navigate().GoToUrl("https://support.accenture.com/bgc_hr/#q=" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString());
        //        }

        //        Thread.Sleep(3000);

        //        by = By.XPath("//*[@id='ess_search_target']/div[2]/div/div/a");
        //        WaitForElementLoad(by, 120);
        //        string sapId = driver.FindElement(by).Text;
        //        sapId = sapId.Substring(sapId.Length - 8);
        //        driver.FindElement(by).Click();

        //        by = By.Id("gsft_main");
        //        WaitForElementLoad(by, 120);
        //        driver.SwitchTo().Frame(driver.FindElement(by));

        //        Thread.Sleep(6000);

        //        //by = By.XPath("//*[@id='f1bb522d371e628074388ff1b3990ed4']");
        //        by = By.Id("f1bb522d371e628074388ff1b3990ed4");
        //        WaitForElementLoad(by, 120);
        //        driver.FindElement(by).Click();

        //        Thread.Sleep(9000);

        //        SendKeys.Send("%(n)"); Thread.Sleep(500);
        //        SendKeys.Send("{TAB}"); Thread.Sleep(500);
        //        SendKeys.Send("{DOWN}"); Thread.Sleep(500);
        //        SendKeys.Send("(s)"); Thread.Sleep(1500);

        //        Thread.Sleep(3000);

        //        by = By.Id("d078ad672bd1ae00acd4d1cc27da1542");
        //        WaitForElementLoad(by, 120);
        //        driver.FindElement(by).Click();

        //        Thread.Sleep(5000);

        //        //string currentWindow = driver.CurrentWindowHandle;
        //        //string popupHandle = string.Empty;
        //        //ReadOnlyCollection<string> windowHandles = driver.WindowHandles;
        //        //foreach (string handle in windowHandles)
        //        //{
        //        //    if (handle != currentWindow)
        //        //    {
        //        //        popupHandle = handle; break;
        //        //    }
        //        //}
        //        //driver.SwitchTo().Window(popupHandle);

        //        by = By.Id("window.BGC Candidate Documents");
        //        WaitForElementLoad(by, 120);
        //        driver.FindElement(by).SendKeys("");

        //        by = By.XPath("//*[@id='displayDetails']/table/tbody");
        //        WaitForElementLoad(by, 120);
        //        IWebElement htmltable = driver.FindElement(by);
        //        IList<IWebElement> rows = htmltable.FindElements(By.TagName("tr"));
        //        int rowCount = rows.Count;
        //        int docCount = 1;

        //        for (int i = 1; i <= rowCount; i++)
        //        {
        //            by = By.XPath("//*[@id='displayDetails']/table/tbody/tr[" + i + "]/td[4]");
        //            WaitForElementLoad(by, 120);
        //            string tdValue = driver.FindElement(by).Text;
        //            if (tdValue == "Service Now")
        //            {
        //                by = By.XPath("//*[@id='displayDetails']/table/tbody/tr[" + i + "]/td[1]");
        //                WaitForElementLoad(by, 120);
        //                string extValue = driver.FindElement(by).Text;

        //                firstPopup = (firstPopup + 1);

        //                if (firstPopup == 1)
        //                {
        //                    if (extValue.Contains(".pdf") || extValue.Contains(".PDF"))
        //                    {
        //                        by = By.XPath("//*[@id='displayDetails']/table/tbody/tr[" + i + "]/td[2]/a");
        //                        WaitForElementLoad(by, 120);
        //                        driver.FindElement(by).SendKeys("");

        //                        SendKeys.Send("+{F10}"); Thread.Sleep(1000);
        //                        SendKeys.Send("{DOWN}"); Thread.Sleep(1000);
        //                        //SendKeys.Send("{DOWN}"); Thread.Sleep(1000);
        //                        SendKeys.Send("{ENTER}"); Thread.Sleep(1000);

        //                        Thread.Sleep(25000);

        //                        //by = By.XPath("//*[@id='displayDetails']/table/tbody/tr[" + i + "]/td[2]/a");
        //                        //WaitForElementLoad(by, 120);
        //                        //driver.FindElement(by).SendKeys("");

        //                        //Thread.Sleep(6000);

        //                        SendKeys.Send("%(n)");
        //                        Thread.Sleep(1000);
        //                        SendKeys.Send("{TAB}");
        //                        Thread.Sleep(1000);
        //                        SendKeys.Send("{DOWN}");
        //                        Thread.Sleep(1000);
        //                        SendKeys.Send("(s)");
        //                        Thread.Sleep(1000);
        //                        docCount = docCount + 1;

        //                        for (int k = 0; k < 50; k--)
        //                        {
        //                            //if (File.Exists(@"C:\Users\" + Environment.UserName + @"\Downloads\" + extValue))
        //                            //{
        //                            //    break;
        //                            //}
        //                            if (Directory.GetFiles(@"C:\Users\" + Environment.UserName + @"\Downloads\", "*.pdf").Length == docCount)
        //                            {
        //                                break;
        //                            }
        //                        }

        //                    }
        //                    else if (extValue.Contains(".jpg"))
        //                    {
        //                        Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
        //                        Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
        //                        Mail.To = Environment.UserName + "@accenture.com";
        //                        Mail.Subject = "RoDo - Download_Jpg_Image_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
        //                        Mail.Save();
        //                        Thread.Sleep(5000);
        //                        firstPopup = firstPopup - 1;
        //                    }
        //                    else if (extValue.Contains(".jpge"))
        //                    {
        //                        Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
        //                        Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
        //                        Mail.To = Environment.UserName + "@accenture.com";
        //                        Mail.Subject = "RoDo - Download_Jpge_Image_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
        //                        Mail.Save();
        //                        Thread.Sleep(5000);
        //                        firstPopup = firstPopup - 1;
        //                    }
        //                    else if (extValue.Contains(".png"))
        //                    {
        //                        Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
        //                        Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
        //                        Mail.To = Environment.UserName + "@accenture.com";
        //                        Mail.Subject = "RoDo - Download_Png_Image_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
        //                        Mail.Save();
        //                        Thread.Sleep(5000);
        //                        firstPopup = firstPopup - 1;
        //                    }
        //                    else if (extValue.Contains(".png.doc"))
        //                    {
        //                        Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
        //                        Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
        //                        Mail.To = Environment.UserName + "@accenture.com";
        //                        Mail.Subject = "RoDo - Download_.png.doc_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
        //                        Mail.Save();
        //                        Thread.Sleep(5000);
        //                        firstPopup = firstPopup - 1;
        //                    }
        //                    else if (extValue.Contains(".msg"))
        //                    {
        //                        Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
        //                        Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
        //                        Mail.To = Environment.UserName + "@accenture.com";
        //                        Mail.Subject = "RoDo - Download_Msg_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
        //                        Mail.Save();
        //                        Thread.Sleep(5000);
        //                        firstPopup = firstPopup - 1;
        //                    }
        //                    else if (extValue.Contains(".zip"))
        //                    {
        //                        Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
        //                        Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
        //                        Mail.To = Environment.UserName + "@accenture.com";
        //                        Mail.Subject = "RoDo - Download_Zip_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
        //                        Mail.Save();
        //                        Thread.Sleep(5000);
        //                        firstPopup = firstPopup - 1;
        //                    }
        //                    else
        //                    {
        //                        Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
        //                        Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
        //                        Mail.To = Environment.UserName + "@accenture.com";
        //                        Mail.Subject = "RoDo - Download_Other_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
        //                        Mail.Save();
        //                        Thread.Sleep(5000);
        //                        firstPopup = firstPopup - 1;
        //                    }
        //                    //Thread.Sleep(5000);
        //                }
        //                else
        //                {
        //                    if (extValue.Contains(".pdf") || extValue.Contains(".PDF"))
        //                    {
        //                        by = By.XPath("//*[@id='displayDetails']/table/tbody/tr[" + i + "]/td[2]/a");
        //                        WaitForElementLoad(by, 120);
        //                        driver.FindElement(by).SendKeys("");

        //                        SendKeys.Send("+{F10}"); Thread.Sleep(1000);
        //                        SendKeys.Send("{DOWN}"); Thread.Sleep(1000);
        //                        //SendKeys.Send("{DOWN}"); Thread.Sleep(1000);
        //                        SendKeys.Send("{ENTER}"); Thread.Sleep(1000);

        //                        Thread.Sleep(5000);

        //                        string currentWindow = driver.CurrentWindowHandle;
        //                        string popupHandle = string.Empty;
        //                        ReadOnlyCollection<string> windowHandles = driver.WindowHandles;
        //                        foreach (string handle in windowHandles)
        //                        {
        //                            if (handle != currentWindow)
        //                            {
        //                                popupHandle = handle; break;
        //                            }
        //                        }

        //                        if (popupHandle != string.Empty)
        //                        {
        //                            driver.SwitchTo().Window(popupHandle);
        //                            driver.Close();
        //                            driver.SwitchTo().Window(currentWindow);
        //                            Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
        //                            Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
        //                            Mail.To = Environment.UserName + "@accenture.com";
        //                            Mail.Subject = "RoDo - Download_Document_NotFound_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
        //                            Mail.Save();
        //                            Thread.Sleep(5000);
        //                            break;
        //                        }


        //                        SendKeys.Send("%(n)"); Thread.Sleep(1000);
        //                        SendKeys.Send("{TAB}"); Thread.Sleep(1000);
        //                        SendKeys.Send("{DOWN}"); Thread.Sleep(1000);
        //                        SendKeys.Send("(s)"); Thread.Sleep(1000);
        //                        docCount = docCount + 1;

        //                        for (int k = 0; k < 50; k--)
        //                        {
        //                            //if (File.Exists(@"C:\Users\" + Environment.UserName + @"\Downloads\" + extValue))
        //                            //{
        //                            //    break;
        //                            //}
        //                            if (Directory.GetFiles(@"C:\Users\" + Environment.UserName + @"\Downloads\", "*.pdf").Length == docCount)
        //                            {
        //                                break;
        //                            }
        //                        }
        //                    }
        //                    else if (extValue.Contains(".jpg"))
        //                    {
        //                        Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
        //                        Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
        //                        Mail.To = Environment.UserName + "@accenture.com";
        //                        Mail.Subject = "RoDo - Download_Jpg_Image_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
        //                        Mail.Save();
        //                        Thread.Sleep(5000);
        //                    }
        //                    else if (extValue.Contains(".jpge"))
        //                    {
        //                        Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
        //                        Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
        //                        Mail.To = Environment.UserName + "@accenture.com";
        //                        Mail.Subject = "RoDo - Download_Jpge_Image_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
        //                        Mail.Save();
        //                        Thread.Sleep(5000);
        //                    }
        //                    else if (extValue.Contains(".png"))
        //                    {
        //                        Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
        //                        Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
        //                        Mail.To = Environment.UserName + "@accenture.com";
        //                        Mail.Subject = "RoDo - Download_Png_Image_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
        //                        Mail.Save();
        //                        Thread.Sleep(5000);
        //                    }
        //                    else if (extValue.Contains(".png.doc"))
        //                    {
        //                        Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
        //                        Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
        //                        Mail.To = Environment.UserName + "@accenture.com";
        //                        Mail.Subject = "RoDo - Download_.png.doc_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
        //                        Mail.Save();
        //                        Thread.Sleep(5000);
        //                    }
        //                    else if (extValue.Contains(".msg"))
        //                    {
        //                        Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
        //                        Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
        //                        Mail.To = Environment.UserName + "@accenture.com";
        //                        Mail.Subject = "RoDo - Download_Msg_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
        //                        Mail.Save();
        //                        Thread.Sleep(5000);
        //                    }
        //                    else if (extValue.Contains(".zip"))
        //                    {
        //                        Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
        //                        Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
        //                        Mail.To = Environment.UserName + "@accenture.com";
        //                        Mail.Subject = "RoDo - Download_Zip_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
        //                        Mail.Save();
        //                        Thread.Sleep(5000);
        //                    }
        //                    else
        //                    {
        //                        Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
        //                        Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
        //                        Mail.To = Environment.UserName + "@accenture.com";
        //                        Mail.Subject = "RoDo - Download_Other_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
        //                        Mail.Save();
        //                        Thread.Sleep(5000);
        //                    }
        //                }
        //            }
        //        }

        //        Thread.Sleep(5000);

        //        string new_folder_path = Main_Folder_Path + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId + @"\";

        //        if (!Directory.Exists(new_folder_path))
        //        {
        //            Directory.CreateDirectory(new_folder_path);
        //        }

        //        foreach (var file in Directory.GetFiles(Download_Folder_Path, "*.pdf"))
        //        {
        //            string FileName = Path.GetFileName(file);
        //            File.Move(file, Path.Combine(new_folder_path, FileName));
        //        }

        //        Thread.Sleep(5000);

        //        GlobalVariable.GlobalDataTable.Rows[data][2] = "Success";

        //    }
        //    catch (Exception exp)
        //    {
        //        AutoClosingMessageBox.Show("Automation Process Incomplete. " + exp.Message, "Error", 9000);
        //        //MessageBox.Show(new Form() { TopMost = true }, "Automation Process Incomplete. " + exp.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //        GlobalVariable.GlobalDataTable.Rows[data][2] = "Error";
        //        driver.SwitchTo().Alert().Accept();
        //        //Environment.Exit(0);
        //    }
        //    //MessageBox.Show(new Form() { TopMost = true }, "Automation Process completeed for Download Docs", "Success", MessageBoxButtons.OK, MessageBoxIcon.None);
        //}

        public static void Download_Doc(int data)
        {
            try
            {
                if (data == 0)
                {
                    //live
                    //by = By.XPath("//*[@id='search-support']/div/input");

                    //stage
                    by = By.XPath("//*[@id='ess_search_input']");
                    WaitForElementLoad(by, 120);

                    //live
                    //driver.Navigate().GoToUrl("https://support.accenture.com/bgc_hr/bgc_index/#q=" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString());

                    //stage
                    driver.Navigate().GoToUrl("https://support-sbox12.accenture.com/bgc_hr/bgc_index/#q=" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString());
                    driver.Navigate().Refresh();
                }
                else
                {
                    //Live
                    //driver.Navigate().GoToUrl("https://support.accenture.com/bgc_hr/bgc_index/#q=" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString());

                    //stage
                    driver.Navigate().GoToUrl("https://support-sbox12.accenture.com/bgc_hr/bgc_index/#q=" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString());

                }

                Thread.Sleep(3000);

                by = By.XPath("//*[@id='ess_search_target']/div[2]/div/div/a");
                WaitForElementLoad(by, 120);
                string sapId = driver.FindElement(by).Text;
                sapId = sapId.Substring(sapId.Length - 8);
                driver.FindElement(by).Click();

                by = By.Id("gsft_main");
                WaitForElementLoad(by, 120);
                driver.SwitchTo().Frame(driver.FindElement(by));

                ((IJavaScriptExecutor)driver).ExecuteScript("document.body.style.transform='scale(0.8)';");

                Thread.Sleep(9000);

                by = By.Id("f1bb522d371e628074388ff1b3990ed4");
                WaitForElementLoad(by, 120);
                driver.FindElement(by).Click();

                Thread.Sleep(9000);

                by = By.Id("d078ad672bd1ae00acd4d1cc27da1542");
                WaitForElementLoad(by, 120);
                driver.FindElement(by).Click();

                Thread.Sleep(5000);

                try
                {
                    by = By.XPath("//*[@id='displayDetails']/table/tbody");
                    WaitForElementLoad(by, 60);
                }
                catch
                {
                    by = By.XPath("//*[@id='window.BGC Candidate Documents']/tbody");
                    WaitForElementLoad(by, 60);
                }
                IWebElement htmltable = driver.FindElement(by);
                IList<IWebElement> rows = htmltable.FindElements(By.TagName("tr"));
                int rowCount = rows.Count;
                int docCount = 1;

                if (50 <= rowCount)
                {
                    Actions actions = new Actions(driver);
                    actions.SendKeys(OpenQA.Selenium.Keys.End).Build().Perform();
                }

                for (int i = 1; i <= rowCount; i++)
                {
                    by = By.XPath("//*[@id='displayDetails']/table/tbody/tr[" + i + "]/td[4]");
                    WaitForElementLoad(by, 120);
                    string tdValue = driver.FindElement(by).Text;
                    if (tdValue == "Service Now")
                    {
                        by = By.XPath("//*[@id='displayDetails']/table/tbody/tr[" + i + "]/td[1]");
                        WaitForElementLoad(by, 120);
                        string extValue = driver.FindElement(by).Text;

                        firstPopup = (firstPopup + 1);


                        if (extValue.Contains(".pdf") || extValue.Contains(".PDF"))
                        {
                            Thread.Sleep(5000);
                            try
                            {
                                by = By.XPath("//*[@id='displayDetails']/table/tbody/tr[" + i + "]/td[2]/a");
                                WaitForElementLoad(by, 120);
                                driver.FindElement(by).Click();
                            }
                            catch
                            {
                                Actions actions = new Actions(driver);
                                actions.SendKeys(OpenQA.Selenium.Keys.End).Build().Perform();
                                Thread.Sleep(2000);
                                actions.SendKeys(OpenQA.Selenium.Keys.End).Build().Perform();
                                Thread.Sleep(2000);
                                driver.FindElement(by).Click();
                            }


                            //RAX 6th May
                            /////string AWS3URL = ASWS3Call("IDC", "C:\\Users\\rakshith.r.bhat\\Downloads\\hr_case.pdf");


                            Thread.Sleep(15000);

                            if (firstPopup == 1)
                            {
                                Thread.Sleep(5000);
                                string currentWindow = driver.CurrentWindowHandle;
                                string popupHandle = string.Empty;
                                ReadOnlyCollection<string> windowHandles = driver.WindowHandles;
                                foreach (string handle in windowHandles)
                                {
                                    if (handle != currentWindow)
                                    {
                                        popupHandle = handle; break;
                                    }
                                }
                                driver.SwitchTo().Window(popupHandle);
                                driver.Close();
                                driver.SwitchTo().Window(currentWindow);
                                by = By.Id("gsft_main");
                                WaitForElementLoad(by, 120);
                                driver.SwitchTo().Frame(driver.FindElement(by));
                            }

                            docCount = docCount + 1;

                            for (int k = 0; k < 50; k--)
                            {
                                int popupCount = driver.WindowHandles.Count;

                                if (Directory.GetFiles(@"C:\Users\" + Environment.UserName + @"\Downloads\", "*.pdf").Length == docCount)
                                {
                                    break;
                                }
                                else if (popupCount != 1)
                                {
                                    Thread.Sleep(5000);
                                    string currentWindow = driver.CurrentWindowHandle;
                                    string popupHandle = string.Empty;
                                    ReadOnlyCollection<string> windowHandles = driver.WindowHandles;
                                    foreach (string handle in windowHandles)
                                    {
                                        if (handle != currentWindow)
                                        {
                                            popupHandle = handle; break;
                                        }
                                    }
                                    driver.SwitchTo().Window(popupHandle);
                                    Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
                                    Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                                    Mail.To = Environment.UserName + "@accenture.com";
                                    Mail.Subject = "RoDo - DocumentNotAvailable_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
                                    Mail.Save();
                                    driver.Close();
                                    driver.SwitchTo().Window(currentWindow);
                                    by = By.Id("gsft_main");
                                    WaitForElementLoad(by, 120);
                                    driver.SwitchTo().Frame(driver.FindElement(by));
                                    break;
                                }
                            }

                        }
                        else if (extValue.Contains(".jpg"))
                        {
                            Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            Mail.To = Environment.UserName + "@accenture.com";
                            Mail.Subject = "RoDo - Download_Jpg_Image_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
                            Mail.Save();
                            Thread.Sleep(5000);
                            firstPopup = firstPopup - 1;
                        }
                        else if (extValue.Contains(".jpge"))
                        {
                            Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            Mail.To = Environment.UserName + "@accenture.com";
                            Mail.Subject = "RoDo - Download_Jpge_Image_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
                            Mail.Save();
                            Thread.Sleep(5000);
                            firstPopup = firstPopup - 1;
                        }
                        else if (extValue.Contains(".png"))
                        {
                            Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            Mail.To = Environment.UserName + "@accenture.com";
                            Mail.Subject = "RoDo - Download_Png_Image_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
                            Mail.Save();
                            Thread.Sleep(5000);
                            firstPopup = firstPopup - 1;
                        }
                        else if (extValue.Contains(".png.doc"))
                        {
                            Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            Mail.To = Environment.UserName + "@accenture.com";
                            Mail.Subject = "RoDo - Download_.png.doc_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
                            Mail.Save();
                            Thread.Sleep(5000);
                            firstPopup = firstPopup - 1;
                        }
                        else if (extValue.Contains(".msg"))
                        {
                            Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            Mail.To = Environment.UserName + "@accenture.com";
                            Mail.Subject = "RoDo - Download_Msg_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
                            Mail.Save();
                            Thread.Sleep(5000);
                            firstPopup = firstPopup - 1;
                        }
                        else if (extValue.Contains(".zip"))
                        {
                            Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            Mail.To = Environment.UserName + "@accenture.com";
                            Mail.Subject = "RoDo - Download_Zip_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
                            Mail.Save();
                            Thread.Sleep(5000);
                            firstPopup = firstPopup - 1;
                        }
                        else
                        {
                            Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            Mail.To = Environment.UserName + "@accenture.com";
                            Mail.Subject = "RoDo - Download_Other_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
                            Mail.Save();
                            Thread.Sleep(5000);
                            firstPopup = firstPopup - 1;
                        }
                    }
                }

                Thread.Sleep(5000);

                string new_folder_path = Main_Folder_Path + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId + @"\";

                if (!Directory.Exists(new_folder_path))
                {
                    Directory.CreateDirectory(new_folder_path);
                }

                foreach (var file in Directory.GetFiles(Download_Folder_Path, "*.pdf"))
                {
                    string FileName = Path.GetFileName(file);
                    File.Move(file, Path.Combine(new_folder_path, FileName));
                }

                Thread.Sleep(5000);

                GlobalVariable.GlobalDataTable.Rows[data][2] = "Success";

            }
            catch (Exception exp)
            {
                AutoClosingMessageBox.Show("Automation Process Incomplete. " + exp.Message, "Error", 9000);
                //MessageBox.Show(new Form() { TopMost = true }, "Automation Process Incomplete. " + exp.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                GlobalVariable.GlobalDataTable.Rows[data][2] = "Error";
                driver.SwitchTo().Alert().Accept();
                //Environment.Exit(0);
            }
            //MessageBox.Show(new Form() { TopMost = true }, "Automation Process completeed for Download Docs", "Success", MessageBoxButtons.OK, MessageBoxIcon.None);
        }

        private static void Download_Doc1(int data)
        {
            try
            {
                //////Thread.Sleep(60000);

                //Commented for Staging module
                ////////////by = By.XPath("//*[@id='ess_search_target']/div[2]/div/div/a");
                ////////////WaitForElementLoad(by, 120);
                ////////////string sapId = driver.FindElement(by).Text;
                ////////////sapId = sapId.Substring(sapId.Length - 8);
                ////////////driver.FindElement(by).Click();

                ////////////by = By.Id("gsft_main");
                ////////////WaitForElementLoad(by, 120);
                ////////////driver.SwitchTo().Frame(driver.FindElement(by));
                /////Comments end




                //STAGING MODULE DIFF NAVIGATION
                if (data > 0)
                {
                    driver.Navigate().GoToUrl(URLChrome);
                    Thread.Sleep(10000);
                }else { Thread.Sleep(10000); }

                Problem_Rcvd:
                //TEST
                ///by = By.XPath("//[@id='filter']");
                ///
                //STAGE
                by = By.XPath("/html/body/div/div/div/nav/div/div[2]/form/div/div/input");
                WaitForElementLoad(by, 240);
                //TEST
                //driver.FindElement(by).SendKeys("Hr_case.LIST");

                //STAGE
                //driver.FindElement(by).SendKeys("Hr Case");




                //string hrcaselistvalue = driver.FindElement(by).GetAttribute("value");
                Thread.Sleep(1000);

                //TEST
                //if (hrcaselistvalue.Equals("Hr_case.LIST") == false) 

                //STAGE
                //////////if (hrcaselistvalue.Equals("HR Case") == false)
                //////////{
                //////////    driver.FindElement(by).Clear();
                //////////    goto Problem_Rcvd;
                //////////}


                //TEST
                //Thread.Sleep(10000);
                // driver.FindElement(by).SendKeys(OpenQA.Selenium.Keys.Enter);

                ////driver.SwitchTo().Window(driver.WindowHandles.Last());
                //STAGE


                //TEST
               //// by = By.XPath("//*[@id='68e173081bd7ac58d4c0437cdc4bcb6b']/div/div");
              // // WaitForElementLoad(by, 120);
                ////////driver.FindElement(by).Click();     
                ////((IJavaScriptExecutor)driver).ExecuteScript("window.open();");
                driver.Navigate().GoToUrl("https://support-stage.accenture.com/hr_case_list.do?sysparm_userpref_module=68e173081bd7ac58d4c0437cdc4bcb6b&sysparm_view=bgc_case&sysparm_clear_stack=true");
                /////driver.SwitchTo().Window(driver.WindowHandles.Last());

                ////////////////////////////Actions action = new Actions(driver);
                ////////////////////////////IWebElement link = driver.FindElement(by);
                //////////////////////////////Hold left shift and press F10
                //////////////////////////////action.MoveToElement(link).DoubleClick().KeyDown(OpenQA.Selenium.Keys.LeftShift).SendKeys(OpenQA.Selenium.Keys.F10).KeyUp(OpenQA.Selenium.Keys.LeftShift).Build().Perform();
                ////////////////////////////action.MoveToElement(link);
                //////////////////////////////action.ContextClick(link).Perform();  // right click

                ////////////////////////////action.ContextClick(link).SendKeys(OpenQA.Selenium.Keys.ArrowDown).SendKeys(OpenQA.Selenium.Keys.Enter).Build().Perform();
                ////////////////////////////action.SendKeys(OpenQA.Selenium.Keys.Control + OpenQA.Selenium.Keys.Return);
                //////////////////////////////action.SendKeys("T").Perform(); // click on new tab
                ////////////////////////////action.SendKeys(OpenQA.Selenium.Keys.Control + 't');
                ////////////////////////////((IJavaScriptExecutor)driver).ExecuteScript("window.open();");

                by = By.XPath("//*[@id='hr_case_table_header_search_control']");
                WaitForElementLoad(by, 120);
                driver.FindElement(by).SendKeys(GlobalVariable.GlobalDataTable.Rows[data]["CID"].ToString());
                driver.FindElement(by).SendKeys(OpenQA.Selenium.Keys.Enter);


                by = By.XPath("/html/body/div[1]/div[1]/span/div/div[6]/table/tbody/tr/td/div/table/tbody/tr/td[3]/a");
                WaitForElementLoad(by, 120);
                driver.FindElement(by).Click();
                ////*[@id="hr_case_table_header_search_control"]
                //STAGING MODULE DIFF NAVIGATION ENDS


                ((IJavaScriptExecutor)driver).ExecuteScript("document.body.style.transform='scale(0.8)';");

                Thread.Sleep(9000);


                //driver.Navigate().Refresh();
                // *[@id = "hr_case.u_bgc_record.u_employee.employee_number"]

                //STAGING MODULE DIFF NAVIGATION
                by = By.XPath("//*[@id='hr_case.u_bgc_record.u_employee.employee_number']");
                WaitForElementLoad(by, 120);
                string sapId = driver.FindElement(by).GetAttribute("value");
                if (string.IsNullOrEmpty(sapId))
                {
                    return;
                }
                //STAGING MODULE DIFF NAVIGATION ENDS




                by = By.Id("f1bb522d371e628074388ff1b3990ed4");
                WaitForElementLoad(by, 120);
                driver.FindElement(by).Click();

                Thread.Sleep(9000);


                ///////((IJavaScriptExecutor)driver).ExecuteScript("window.scrollBy(0,800)", "");
                IWebElement elm = driver.FindElement(By.Id("d078ad672bd1ae00acd4d1cc27da1542"));
                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", elm);
                //////////////////////////by = By.XPath("//*[@id='hr_case.form_scroll']");
                //////////////////////////WaitForElementLoad(by, 120);
                //////////////////////////driver.FindElement(by).SendKeys(OpenQA.Selenium.Keys.PageDown);
                //////////////////////////driver.FindElement(by).SendKeys(OpenQA.Selenium.Keys.PageDown);


                by = By.Id("d078ad672bd1ae00acd4d1cc27da1542");
                WaitForElementLoad(by, 120);
                driver.FindElement(by).Click();

                Thread.Sleep(5000);

                Returningfrompreviouspage:
                try
                {
                    by = By.XPath("//*[@id='displayDetails']/table/tbody");
                    WaitForElementLoad(by, 60);
                }
                catch
                {
                    by = By.XPath("//*[@id='window.BGC Candidate Documents']/tbody");
                    WaitForElementLoad(by, 60);
                }
                IWebElement htmltable = driver.FindElement(by);
                IList<IWebElement> rows = htmltable.FindElements(By.TagName("tr"));
                int rowCount = rows.Count;
                int docCount = 1;

                if (50 <= rowCount)
                {
                    Actions actions = new Actions(driver);
                    actions.SendKeys(OpenQA.Selenium.Keys.End).Build().Perform();
                }

                for (int i = 1; i <= rowCount; i++)
                {
                    by = By.XPath("//*[@id='displayDetails']/table/tbody/tr[" + i + "]/td[4]");
                    WaitForElementLoad(by, 120);
                    string tdValue = driver.FindElement(by).Text;
                    if (tdValue == "Service Now")
                    {
                        by = By.XPath("//*[@id='displayDetails']/table/tbody/tr[" + i + "]/td[1]");
                        WaitForElementLoad(by, 120);
                        string extValue = driver.FindElement(by).Text;

                        firstPopup = (firstPopup + 1);


                        if (extValue.Contains(".pdf") || extValue.Contains(".PDF"))
                        {
                            Thread.Sleep(5000);
                            try
                            {
                                by = By.XPath("//*[@id='displayDetails']/table/tbody/tr[" + i + "]/td[2]/a");
                                WaitForElementLoad(by, 120);
                                driver.FindElement(by).Click();
                            }
                            catch
                            {
                                Actions actions = new Actions(driver);
                                actions.SendKeys(OpenQA.Selenium.Keys.End).Build().Perform();
                                Thread.Sleep(2000);
                                actions.SendKeys(OpenQA.Selenium.Keys.End).Build().Perform();
                                Thread.Sleep(2000);
                                driver.FindElement(by).Click();
                            }

                            Thread.Sleep(15000);
                            //RAX 6th May
                            /////////string AWS3URL = ASWS3Call("IDC", "C:\\Users\\rakshith.r.bhat\\Downloads\\hr_case.pdf");
                            if (firstPopup == 1)
                            {
                                Thread.Sleep(5000);
                                string currentWindow = driver.CurrentWindowHandle;
                                string popupHandle = string.Empty;
                                ReadOnlyCollection<string> windowHandles = driver.WindowHandles;
                                foreach (string handle in windowHandles)
                                {
                                    if (handle != currentWindow)
                                    {
                                        popupHandle = handle; break;
                                    }
                                }
                                driver.SwitchTo().Window(popupHandle);
                                driver.Close();
                                driver.SwitchTo().Window(currentWindow);
                                //Rax May25
                                goto Returningfrompreviouspage;
                                //Rax May25 ends
                                by = By.Id("gsft_main");
                                WaitForElementLoad(by, 120);
                                driver.SwitchTo().Frame(driver.FindElement(by));
                            }

                            docCount = docCount + 1;

                            for (int k = 0; k < 50; k--)
                            {
                                int popupCount = driver.WindowHandles.Count;

                                if (Directory.GetFiles(@"C:\Users\" + Environment.UserName + @"\Downloads\", "*.pdf").Length == docCount)
                                {
                                    break;
                                }
                                else if (popupCount != 1)
                                {
                                    Thread.Sleep(5000);
                                    string currentWindow = driver.CurrentWindowHandle;
                                    string popupHandle = string.Empty;
                                    ReadOnlyCollection<string> windowHandles = driver.WindowHandles;
                                    foreach (string handle in windowHandles)
                                    {
                                        if (handle != currentWindow)
                                        {
                                            popupHandle = handle; break;
                                        }
                                    }
                                    driver.SwitchTo().Window(popupHandle);
                                    Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
                                    Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                                    Mail.To = Environment.UserName + "@accenture.com";
                                    Mail.Subject = "RoDo - DocumentNotAvailable_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
                                    Mail.Save();
                                    driver.Close();
                                    driver.SwitchTo().Window(currentWindow);
                                    by = By.Id("gsft_main");
                                    WaitForElementLoad(by, 120);
                                    driver.SwitchTo().Frame(driver.FindElement(by));
                                    break;
                                }
                            }

                        }
                        else if (extValue.Contains(".jpg"))
                        {
                            Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            Mail.To = Environment.UserName + "@accenture.com";
                            Mail.Subject = "RoDo - Download_Jpg_Image_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
                            Mail.Save();
                            Thread.Sleep(5000);
                            firstPopup = firstPopup - 1;
                        }
                        else if (extValue.Contains(".jpge"))
                        {
                            Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            Mail.To = Environment.UserName + "@accenture.com";
                            Mail.Subject = "RoDo - Download_Jpge_Image_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
                            Mail.Save();
                            Thread.Sleep(5000);
                            firstPopup = firstPopup - 1;
                        }
                        else if (extValue.Contains(".png"))
                        {
                            Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            Mail.To = Environment.UserName + "@accenture.com";
                            Mail.Subject = "RoDo - Download_Png_Image_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
                            Mail.Save();
                            Thread.Sleep(5000);
                            firstPopup = firstPopup - 1;
                        }
                        else if (extValue.Contains(".png.doc"))
                        {
                            Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            Mail.To = Environment.UserName + "@accenture.com";
                            Mail.Subject = "RoDo - Download_.png.doc_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
                            Mail.Save();
                            Thread.Sleep(5000);
                            firstPopup = firstPopup - 1;
                        }
                        else if (extValue.Contains(".msg"))
                        {
                            Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            Mail.To = Environment.UserName + "@accenture.com";
                            Mail.Subject = "RoDo - Download_Msg_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
                            Mail.Save();
                            Thread.Sleep(5000);
                            firstPopup = firstPopup - 1;
                        }
                        else if (extValue.Contains(".zip"))
                        {
                            Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            Mail.To = Environment.UserName + "@accenture.com";
                            Mail.Subject = "RoDo - Download_Zip_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
                            Mail.Save();
                            Thread.Sleep(5000);
                            firstPopup = firstPopup - 1;
                        }
                        else
                        {
                            Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            Mail.To = Environment.UserName + "@accenture.com";
                            Mail.Subject = "RoDo - Download_Other_Error_" + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId;
                            Mail.Save();
                            Thread.Sleep(5000);
                            firstPopup = firstPopup - 1;
                        }
                    }
                }

                Thread.Sleep(5000);

                /////////string new_folder_path = Main_Folder_Path + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + sapId + @"\";

                string new_folder_path = Main_Folder_Path + GlobalVariable.GlobalDataTable.Rows[data][0].ToString() + "_" + GlobalVariable.GlobalDataTable.Rows[data][1].ToString() + "_" + sapId + @"\";

                if (!Directory.Exists(new_folder_path))
                {
                    Directory.CreateDirectory(new_folder_path);
                }

                foreach (var file in Directory.GetFiles(Download_Folder_Path, "*.pdf"))
                {
                    string FileName = Path.GetFileName(file);
                    File.Move(file, Path.Combine(new_folder_path, FileName));
                }

                Thread.Sleep(5000);

                GlobalVariable.GlobalDataTable.Rows[data][2] = "Success";

            }
            catch (Exception exp)
            {
                AutoClosingMessageBox.Show("Automation Process Incomplete. " + exp.Message, "Error", 9000);
                //MessageBox.Show(new Form() { TopMost = true }, "Automation Process Incomplete. " + exp.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                GlobalVariable.GlobalDataTable.Rows[data][2] = "Error";

                //RAX
                //Commented for staging
                ///driver.SwitchTo().Alert().Accept();


                //Environment.Exit(0);
            }
            //MessageBox.Show(new Form() { TopMost = true }, "Automation Process completeed for Download Docs", "Success", MessageBoxButtons.OK, MessageBoxIcon.None);
        }

        public static void Rearrange_Docs()
        {
            try
            {
                DirectoryInfo info = new DirectoryInfo(Main_Folder_Path);
                foreach (DirectoryInfo subinfo in info.GetDirectories())
                {
                    int Snow = 0, Criminal = 0, previous_comp = 0, Employee = 0, Curr_comp = 0, Education = 0, Final = 0;
                    foreach (FileInfo file in subinfo.GetFiles())
                    {
                        string fileName = Path.GetFileNameWithoutExtension(file.Name);
                        string ext = file.Extension;
                        if (fileName.Contains("hr"))
                        {
                            Snow = Snow + 1;
                            string Fromfile = Main_Folder_Path + subinfo + @"\" + fileName + ext;
                            string Tofile = Main_Folder_Path + subinfo + @"\1_SNOW" + Snow.ToString() + ext;
                            File.Move(Fromfile, Tofile);
                        }
                        if (fileName.ToUpper().Contains("DB"))
                        {
                            Criminal = Criminal + 1;
                            string Fromfile = Main_Folder_Path + subinfo + @"\" + fileName + ext;
                            string Tofile = Main_Folder_Path + subinfo + @"\2_Criminal" + Criminal.ToString() + ext;
                            File.Move(Fromfile, Tofile);
                        }
                        if (fileName.ToUpper().Contains("PRE_COM"))
                        {
                            previous_comp = previous_comp + 1;
                            string Fromfile = Main_Folder_Path + subinfo + @"\" + fileName + ext;
                            string Tofile = Main_Folder_Path + subinfo + @"\3_Previous Company" + previous_comp.ToString() + ext;
                            File.Move(Fromfile, Tofile);
                        }
                        if (fileName.ToUpper().Contains("PRE_EMP"))
                        {
                            Employee = Employee + 1;
                            string Fromfile = Main_Folder_Path + subinfo + @"\" + fileName + ext;
                            string Tofile = Main_Folder_Path + subinfo + @"\4_Employee" + Employee.ToString() + ext;
                            File.Move(Fromfile, Tofile);
                        }
                        if (fileName.ToUpper().Contains("CE_COM"))
                        {
                            Curr_comp = Curr_comp + 1;
                            string Fromfile = Main_Folder_Path + subinfo + @"\" + fileName + ext;
                            string Tofile = Main_Folder_Path + subinfo + @"\5_Current Company" + Curr_comp.ToString() + ext;
                            File.Move(Fromfile, Tofile);
                        }
                        if (fileName.ToUpper().Contains("EDU"))
                        {
                            Education = Education + 1;
                            string Fromfile = Main_Folder_Path + subinfo + @"\" + fileName + ext;
                            string Tofile = Main_Folder_Path + subinfo + @"\6_Education" + Education.ToString() + ext;
                            File.Move(Fromfile, Tofile);
                        }
                        if (fileName.ToUpper().Contains("CE_EMP"))
                        {
                            Final = Final + 1;
                            string Fromfile = Main_Folder_Path + subinfo + @"\" + fileName + ext;
                            string Tofile = Main_Folder_Path + subinfo + @"\7_Final" + Final.ToString() + ext;
                            File.Move(Fromfile, Tofile);
                        }
                    }
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show(new Form() { TopMost = true }, "Automation Process Incomplete. " + exp.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //Environment.Exit(0);
            }
            //MessageBox.Show(new Form() { TopMost = true }, "Automation Process completeed for Rearrange Docs", "Success", MessageBoxButtons.OK, MessageBoxIcon.None);
        }

        public static void Merge_Docs()
        {
            try
            {
                mergeFilesInFolder();
            }
            catch (Exception exp)
            {
                MessageBox.Show(new Form() { TopMost = true }, "Automation Process Incomplete. " + exp.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //Environment.Exit(0);
            }
            //DirectoryInfo info = new DirectoryInfo(Main_Folder_Path);
            //foreach (DirectoryInfo subinfo in info.GetDirectories())
            //{
            //    foreach (FileInfo file in subinfo.GetFiles())
            //    {
            //        file.Delete();
            //    }
            //    subinfo.Delete();
            //}
            //MessageBox.Show(new Form() { TopMost = true }, "Automation Process completeed for Merge Docs" , "Success", MessageBoxButtons.OK, MessageBoxIcon.None);
        }

        public static bool isDirectoryContainFiles(string path)
        {
            if (Directory.GetFiles(path).Length > 0)
                return true;
            else
                return false;
        }

        public static string isAnyDocumentPresent()
        {
            StringBuilder sb = new StringBuilder();

            string mainFolder = Main_Folder_Path;
            string[] subFolders = Directory.GetDirectories(mainFolder);

            foreach (string folder in subFolders)
            {
                if (isDirectoryContainFiles(folder))
                {
                    string folderName = Path.GetFileName(folder);
                    sb.Append(folderName);
                    sb.Append(",");
                }
            }

            if (sb.Length > 0)
            {
                string strFilesPresentInFolders = sb.ToString();
                strFilesPresentInFolders = strFilesPresentInFolders.Substring(0, strFilesPresentInFolders.Length - 1);
                return strFilesPresentInFolders;
            }
            else
            {
                MessageBox.Show("No Files are present in the folder:" + mainFolder);
                return "";
            }
        }

        public static void mergeFilesInFolder()
        {
            string folderContainingFiles = isAnyDocumentPresent();
            if (folderContainingFiles.Length > 0)
            {
                hasSubFolder = true;
            }

            if (hasSubFolder)
            {
                string[] subFolders = Directory.GetDirectories(Main_Folder_Path);
                foreach (string firstLevelFolder in subFolders)
                {
                    try
                    {
                        Attach_Filename_in_first_page(firstLevelFolder);
                    }
                    catch (Exception ex)
                    {
                        //dictonaryStatus[firstLevelFolder] = false;
                    }
                }

                string[] subFoldersSign = Directory.GetDirectories(Signature_Folder_Path);
                foreach (string firstLevelFolder in subFoldersSign)
                {
                    try
                    {
                        merge(firstLevelFolder);
                        if (PasswordPDF == "Yes")
                        {
                            String folderName = Path.GetFileName(firstLevelFolder);

                            Microsoft.Office.Interop.Outlook.Application outl = new Microsoft.Office.Interop.Outlook.Application();
                            Microsoft.Office.Interop.Outlook.MailItem Mail = (Microsoft.Office.Interop.Outlook.MailItem)outl.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
                            Mail.To = Environment.UserName + "@accenture.com";
                            Mail.Subject = "RoDo - Merging_Error_" + folderName;
                            Mail.Save();
                            Thread.Sleep(6000);
                        }
                    }
                    catch (Exception ex)
                    {
                        //dictonaryStatus[firstLevelFolder] = false;
                    }
                }
            }
        }

        public static void merge(string firstLevelFolder)
        {
            string[] filename = Directory.GetFiles(firstLevelFolder, "*.pdf", SearchOption.TopDirectoryOnly);
            if (filename.Length > 0)
            {
                String folderName = Path.GetFileName(firstLevelFolder);
                String sapId = folderName.Substring(folderName.Length - 8);
                //*************************Checks for number of pages in a pdf and merges**********************
                PdfReader reader = null;
                Document sourceDocument = null;
                PdfCopy pdfCopyProvider = null;
                PdfImportedPage importedPage = default(PdfImportedPage);

                string outputPdfPath = Pending_Folder_Path + sapId + ".pdf";

                sourceDocument = new Document();
                pdfCopyProvider = new PdfCopy(sourceDocument, new FileStream(outputPdfPath, FileMode.Create));
                //Open the output file
                sourceDocument.Open();

                try
                {
                    foreach (string files in filename)
                    {
                        try
                        {
                            PdfReader.unethicalreading = true;
                            reader = new PdfReader(files);
                            reader.ConsolidateNamedDestinations();

                            int pages = get_pageCount(files);

                            for (int i = 1; i <= pages; i++)
                            {
                                importedPage = pdfCopyProvider.GetImportedPage(reader, i);
                                pdfCopyProvider.AddPage(importedPage);
                            }

                            PasswordPDF = "No";

                            reader.Close();
                        }
                        catch
                        {
                            PasswordPDF = "Yes";
                            reader.Close();
                        }
                    }

                    pdfCopyProvider.Close();
                    sourceDocument.Close();
                }
                catch (System.Exception ex)
                {
                    throw ex;
                }
            }
            else
            {
                return;
            }
        }

        public static void Attach_Filename_in_first_page(string firstLevelFolder)
        {
            string[] filename = Directory.GetFiles(firstLevelFolder, "*.pdf", SearchOption.TopDirectoryOnly);
            string PdfFilePath = "";
            string fileName = "";
            string signature1 = "";
            string filepath = "";
            string extension = "";

            if (filename.Length > 0)
            {
                for (int i = 0; i <= System.Convert.ToDouble(filename.Count()) - 1; i++)
                {
                    // ************ Get filepath **************'
                    PdfFilePath = filename[i];
                    // ******** End ******************'

                    // ********** Get file name **********'
                    FileInfo FileInfo = new FileInfo(PdfFilePath);
                    // dirName1 = System.IO.Path.GetDirectoryName(zMailbox)
                    string[] split = PdfFilePath.Split('\\');
                    string dirName1 = split[split.Length - 1];
                    fileName = System.IO.Path.GetFileNameWithoutExtension(FileInfo.ToString());

                    if (fileName.Contains("1_SNOW"))
                        signature1 = "Snow";
                    else if (fileName.Contains("2_Criminal"))
                        signature1 = "Criminal";
                    else if (fileName.Contains("3_Previous Company"))
                        signature1 = "Previous_Company";
                    else if (fileName.Contains("4_Employee"))
                        signature1 = "Employee";
                    else if (fileName.Contains("5_Current Company"))
                        signature1 = "Current_Company";
                    else if (fileName.Contains("6_Education"))
                        signature1 = "Education";
                    else if (fileName.Contains("7_Final"))
                        signature1 = "Final";

                    // *********** Get File Extention or a fileType ************'
                    filepath = PdfFilePath;
                    extension = System.IO.Path.GetExtension(PdfFilePath);
                    string lastFolderName = Path.GetFileName(Path.GetDirectoryName(PdfFilePath));
                    string new_folder_path = Signature_Folder_Path + lastFolderName + @"\";

                    if (!Directory.Exists(new_folder_path))
                        Directory.CreateDirectory(new_folder_path);


                    //if (!Directory.Exists("" + path1 + @" \Documents_DONT_DELETE\" + txt_CID.Text + @"\attachment_multiple_page"))
                    //    Directory.CreateDirectory("" + path1 + @" \Documents_DONT_DELETE\" + txt_CID.Text + @"\attachment_multiple_page");

                    No_of_Pages(1, PdfFilePath);

                    if (numberOfPages == 1)
                    {

                        // ******************* Add uploaded text onto the pdf ************************'
                        // Dim filepat As String = "" & path1 & " \Documents_DONT_DELETE\" & txt_CID.Text & "\Skil_from_db.pdf"
                        ArrayList FileArr = new ArrayList();

                        PdfReader reader = new PdfReader(filepath);

                        iTextSharp.text.Rectangle size = reader.GetPageSizeWithRotation(1);
                        iTextSharp.text.Document document = new iTextSharp.text.Document(size);

                        // Create the writer
                        FileStream fs = new FileStream(new_folder_path + fileName + extension, FileMode.Create, FileAccess.Write, FileShare.None);
                        PdfWriter writer = PdfWriter.GetInstance(document, fs);
                        document.Open();

                        PdfContentByte cb = writer.DirectContent;

                        BaseFont bf = BaseFont.CreateFont(BaseFont.COURIER_BOLDOBLIQUE, BaseFont.CP1257, BaseFont.NOT_EMBEDDED);

                        cb.SetColorFill(BaseColor.BLACK);

                        cb.SetFontAndSize(bf, 14);
                        PdfImportedPage page = writer.GetImportedPage(reader, 1);

                        cb.AddTemplate(page, 0, 0);
                        // ******************** Print Values
                        cb.BeginText();

                        // Set the alignment and coordinates here

                        cb.ShowTextAligned(1, fileName, 450, 770, 0);

                        cb.SetTextRenderingMode(PdfContentByte.TEXT_RENDER_MODE_FILL_STROKE);
                        cb.EndText();


                        document.Close();
                        fs.Close();
                        writer.Close();
                        reader.Close();
                    }
                    else
                    {
                        ArrayList FileArr = new ArrayList();

                        PdfReader reader = new PdfReader(filepath);

                        iTextSharp.text.Rectangle size = reader.GetPageSizeWithRotation(1);
                        iTextSharp.text.Document document = new iTextSharp.text.Document(size);

                        // Create the writer
                        FileStream fs = new FileStream(new_folder_path + fileName + extension, FileMode.Create, FileAccess.Write, FileShare.None);
                        PdfWriter writer = PdfWriter.GetInstance(document, fs);
                        document.Open();

                        for (int p = 1; p < (numberOfPages + 1); p++)
                        {
                            document.NewPage();
                            PdfContentByte cb = writer.DirectContent;
                            BaseFont bf = BaseFont.CreateFont(BaseFont.COURIER_BOLDOBLIQUE, BaseFont.CP1257, BaseFont.NOT_EMBEDDED);

                            cb.SetColorFill(BaseColor.BLACK);

                            cb.SetFontAndSize(bf, 14);
                            PdfImportedPage page = writer.GetImportedPage(reader, p);

                            cb.AddTemplate(page, 0, 0);
                            // ******************** Print Values
                            cb.BeginText();

                            // Set the alignment and coordinates here

                            cb.ShowTextAligned(1, signature1, 450, 770, 0);

                            cb.SetTextRenderingMode(PdfContentByte.TEXT_RENDER_MODE_FILL_STROKE);

                            cb.EndText();
                        }


                        document.Close();
                        fs.Close();
                        writer.Close();
                        reader.Close();
                    }
                }
            }

        }

        //public void Delete_pdf_page()
        //{
        //    string templatePdf = "";

        //    bool result = false;
        //    iTextSharp.text.pdf.PdfReader template = null/* TODO Change to default(_) if this is not a reference type ;
        //    iTextSharp.text.pdf.PdfReader reader = null/* TODO Change to default(_) if this is not a reference type */;
        //    iTextSharp.text.Document doc = null/* TODO Change to default(_) if this is not a reference type */;
        //    iTextSharp.text.pdf.PdfCopy copier = null/* TODO Change to default(_) if this is not a reference type */;
        //    bool deleteTemplate1 = false;

        //    sourcePdf = filepath;
        //    destination = "" + path1 + @" \Documents_DONT_DELETE\" + txt_CID.Text + @"\attachment_multiple_page\Pages.pdf";

        //    try
        //    {
        //        reader = new iTextSharp.text.pdf.PdfReader(sourcePdf);
        //        if (string.IsNullOrEmpty(templatePdf))
        //        {
        //            templatePdf = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\BlankPageTemplate.pdf";
        //            deleteTemplate1 = true;
        //            iTextSharp.text.Document tpdoc = new iTextSharp.text.Document(reader.GetPageSizeWithRotation(1));
        //            iTextSharp.text.pdf.PdfWriter tpwriter = iTextSharp.text.pdf.PdfWriter.GetInstance(tpdoc, new System.IO.FileStream(templatePdf, System.IO.FileMode.Create));
        //            tpdoc.Open();
        //            tpdoc.Add(new iTextSharp.text.Paragraph(" "));
        //            tpdoc.Close();
        //        }
        //        template = new iTextSharp.text.pdf.PdfReader(templatePdf);
        //        doc = new iTextSharp.text.Document(reader.GetPageSizeWithRotation(1));
        //        copier = new iTextSharp.text.pdf.PdfCopy(doc, new System.IO.FileStream(destination, System.IO.FileMode.Create));
        //        doc.Open();
        //        for (int i = 1; i <= reader.NumberOfPages; i++)
        //        {
        //            // If pagesToReplace.Contains(i) Then
        //            // copier.AddPage(copier.GetImportedPage(template, 1))
        //            // Else
        //            // copier.AddPage(copier.GetImportedPage(reader, i))
        //            // End If

        //            if (i == 1)
        //            {
        //            }
        //            else
        //                copier.AddPage(copier.GetImportedPage(reader, i));
        //        }

        //        doc.Close();
        //        template.Close();
        //        reader.Close();
        //        result = true;

        //        if (deleteTemplate1)
        //            System.IO.File.Delete(templatePdf);
        //    }
        //    catch (Exception ex)
        //    {
        //        // Put your own code to handle exception here
        //        Debug.Write(ex.Message);
        //    }
        //    return;
        //}

        public static int No_of_Pages(int Doc, string PdfFilePath)
        {
            try
            {
                PdfReader pdfReader = new PdfReader(PdfFilePath);
                numberOfPages = pdfReader.NumberOfPages;
                return numberOfPages;
            }
            catch (Exception ex)
            {
                PdfReader pdfReader = new PdfReader(PdfFilePath);
                numberOfPages = pdfReader.NumberOfPages;
                return numberOfPages;
            }
        }

        public static int get_pageCount(string file)
        {
            string ppath = file;
            PdfReader pdfReader = new PdfReader(ppath);
            int numberOfPages = pdfReader.NumberOfPages;
            return numberOfPages;
        }

        public static void Convert_Tiff()
        {
            try
            {
                Process pdf2tif;
                pdf2tif = Process.Start(IE_DRIVER_PATH + "PDF_TIF.exe");
                pdf2tif.WaitForExit();
                pdf2tif.Close();

                MessageBox.Show(new Form() { TopMost = true }, "Automation Process completeed for Covert Docs to Tif", "Success", MessageBoxButtons.OK, MessageBoxIcon.None);
            }
            catch (Exception exp)
            {
                MessageBox.Show(new Form() { TopMost = true }, "Automation Process Incomplete. " + exp.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //Environment.Exit(0);
            }
        }

        public static void Api(string toolname, string Start_Time, string End_Time)
        {
            var request = (HttpWebRequest)WebRequest.Create("https://ssautomation.accenture.com/e_travel_api/api/values");
            var postData = "tool_name=" + toolname + "&start_time=" + Start_Time + "&end_time=" + End_Time + "&total_time=" + (Convert.ToDateTime(End_Time) - Convert.ToDateTime(Start_Time)).ToString() + "&count=" + GlobalVariable.GlobalDataTable.Rows.Count.ToString() + "&submitted_by=" + Environment.UserName + "&uploaded_date=" + DateTime.Now.Date + "";
            var data = Encoding.ASCII.GetBytes(postData);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("x-api-key", "F1EEA6B6-2FBD-4887-96E2-07024C37BC6F");
            request.ContentLength = data.Length;
            using (var stream = request.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }
            var response = (HttpWebResponse)request.GetResponse();
            var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
        }

        //////////public static string ASWS3Call(string Entity,string FilePath)
        //////////{
        //////////    string filename = Path.GetFileName(FilePath);            
        //////////    string S3URL = "https://accentureindia-abacus-candidatedocuments-stage.s3.amazonaws.com/" + Entity + "/" + filename  + "X-Amz-Expires=86400&X-Amz-Date=20210510T185020Z&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAVKXJ3K7W7EB7BHUJ%2F20210510%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-SignedHeaders=host&X-Amz-Signature=e16c1bfebe7bce1412c1ee3300aa7f56338568b9e18d9b39d963e68f7c62ccd5";
        //////////    var client = new RestClient(S3URL);
        //////////    client.Timeout = -1;
        //////////    var request = new RestRequest(Method.PUT);
        //////////    request.AddHeader("Content-Type", "image/tiff");
        //////////    request.AddParameter("image/tiff", "<file contents here>", ParameterType.RequestBody);
        //////////    IRestResponse response = client.Execute(request);
        //////////    return S3URL;



        //////////    //var client = new RestClient("accentureindia-abacus-candidatedocuments-stage.s3.amazonaws.com/IDC/10101010_10th Marked Sheet_04232021_16571851.tif?X-Amz-Expires=86400&X-Amz-Date=20210510T185559Z&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAVKXJ3K7W7EB7BHUJ%2F20210510%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-SignedHeaders=host&X-Amz-Signature=77eb6e41fbba3fd6790bf890201df19a90294fc3150c3076150140c0f680f4fc");
        //////////    //client.Timeout = -1;
        //////////    //var request = new RestRequest(Method.PUT);
        //////////    //request.AddHeader("Content-Type", "image/tiff");
        //////////    //request.AddParameter("image/tiff", "<file contents here>", ParameterType.RequestBody);
        //////////    //IRestResponse response = client.Execute(request);
        //////////    //Console.WriteLine(response.Content);
        //////////}


        //public static string  AWS3Call2(string Entity,string FilePath)
        //{
        //    //string filename = Path.GetFileName(FilePath);
        //    // Connect to Amazon S3 service with authentication
        //    BasicAWSCredentials basicCredentials =
        //        new BasicAWSCredentials("AKIAVKXJ3K7W7EB7BHUJ",
        //        "Y+WtFMj35rXA/KeXNxWe5HVR6tCjiid139b99dsk");
        //    AmazonS3Client s3Client = new AmazonS3Client(basicCredentials);

        //    // Display all S3 buckets
        //    ListBucketsResponse buckets = s3Client.ListBuckets();
        //    foreach (var bucket in buckets.Buckets)
        //    {
        //        Console.WriteLine(bucket.BucketName);
        //    }

        //    // Display and download the files in the first S3 bucket
        //    string bucketName = buckets.Buckets[0].BucketName;
        //    Console.WriteLine("Objects in bucket '{0}':", bucketName);
        //    ListObjectsResponse objects =
        //        s3Client.ListObjects(new ListObjectsRequest() { BucketName = bucketName });
        //    foreach (var s3Object in objects.S3Objects)
        //    {
        //        Console.WriteLine("\t{0} ({1})", s3Object.Key, s3Object.Size);
        //        if (s3Object.Size > 0)
        //        {
        //            // We have a file (not a directory) --> download it
        //            GetObjectResponse objData = s3Client.GetObject(
        //                new GetObjectRequest() { BucketName = bucketName, Key = s3Object.Key });
        //            string s3FileName = new FileInfo(s3Object.Key).Name;
        //            SaveStreamToFile(objData.ResponseStream, s3FileName);
        //        }
        //    }

        //    // Create a new directory and upload a file in it
        //    //string path = "uploads/new_folder_" + DateTime.Now.Ticks;
        //    string path = FilePath;
        //    string newFileName = Path.GetFileName(FilePath);
        //    string fullFileName = path + "/" + newFileName;
        //    string fileContents = "This is an example file created through the Amazon S3 API.";
        //    s3Client.PutObject(new PutObjectRequest()
        //    {
        //        BucketName = bucketName,
        //        Key = fullFileName,
        //        ContentBody = fileContents
        //    }
        //    );
        //    Console.WriteLine("Created a file in Amazon S3: {0}", fullFileName);

        //    // Share the uploaded file and get a download URL
        //    string uploadedFileUrl = s3Client.GetPreSignedURL(new GetPreSignedUrlRequest()
        //    {
        //        BucketName = bucketName,
        //        Key = fullFileName,
        //        Expires = DateTime.Now.AddYears(5)
        //    });
        //    Console.WriteLine("File download URL: {0}", uploadedFileUrl);
        //    return uploadedFileUrl;
        //    //System.Diagnostics.Process.Start(uploadedFileUrl);
        //}

        //private static void SaveStreamToFile(Stream inputStream, string fileName)
        //{
        //    using (FileStream outputFile = new FileStream(fileName, FileMode.Create))
        //    {
        //        byte[] buf = new byte[BUFFER_SIZE];
        //        while (true)
        //        {
        //            int bytesRead = inputStream.Read(buf, 0, buf.Length);
        //            if (bytesRead == 0)
        //            {
        //                break;
        //            }
        //            outputFile.Write(buf, 0, bytesRead);
        //        }
        //    }
        //}



    }
}
