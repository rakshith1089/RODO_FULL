﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Snow_Tool
{
    public partial class PendingCIDList : Form
    {
        DataTable details;
        ToolTip toolTip1 = new ToolTip();
        classPendingCIDs pcid;
        public PendingCIDList()
        {
            InitializeComponent();
        }

        private void btn_SearchPendingCIDs_Click(object sender, EventArgs e)
        {
            if (cbo_CIDCount.SelectedIndex == -1)
            {

                //}
                toolTip1.ShowAlways = true;
                toolTip1.Show("Select an Option", cbo_CIDCount);
                return;
            }
            pcid = new classPendingCIDs();
            details = pcid.func_getPendingCIDList(Convert.ToInt32(cbo_CIDCount.Text), "https://ssautomation.accenture.com/RODO_API/api/GetCID/GetPendingCIDsList");//"http://localhost:52918/api/GetCID/GetPendingCIDsList");
            dgv_PendingList.DataSource = details;
            GlobalVariable.GlobalDataTable = details.Copy();
            lbl_TotalCIDs.Text = (dgv_PendingList.Rows.Count - 1).ToString();
            btn_Convert.Enabled = true;
        }

        private void btn_Convert_Click(object sender, EventArgs e)
        {
            //GlobalVariable.GlobalDataTable = details;
            //foreach (DataRow row in details.Rows)
            //{
            Operation.ExecuteOperation();
            Login l = new Login();
            l.Excel();

            //}
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            dgv_PendingList.DataSource = null;
            lbl_TotalCIDs.Text = "0";
            cbo_CIDCount.SelectedIndex = -1;
        }

        private void PendingCIDList_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            var login = new Login();
            login.Closed += (s, args) => this.Close();
            login.Show();
        }
    }
}
