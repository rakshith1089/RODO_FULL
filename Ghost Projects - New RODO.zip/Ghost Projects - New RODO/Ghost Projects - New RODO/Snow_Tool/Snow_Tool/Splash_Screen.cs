﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Snow_Tool
{
    public partial class Splash_Screen : Form
    {
        public Splash_Screen()
        {
            InitializeComponent();
        }
        int second = 0;

        private void Splash_Screen_Load(object sender, EventArgs e)
        {
            timer1.Interval = 1000;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            second = second + 1;
            this.Opacity += 0.2;
            if (second >= 6)
            {
                this.Opacity = 0.1;
                timer1.Stop();
                //Application.Run(new Login());
                Login form = new Login();
                form.Show();
                this.Hide();
            }
        }

    }
}
