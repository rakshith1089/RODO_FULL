﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Data.OleDb;
using System.Net;
using System.IO;
using System.Web;
using OfficeOpenXml;

namespace Snow_Tool
{
    public partial class Login : Form
    {

        public string ExcellName = "";

        public Login()
        {
            // Remove insecure protocols (SSL3, TLS 1.0, TLS 1.1)
            ServicePointManager.SecurityProtocol &= ~SecurityProtocolType.Ssl3;
            ServicePointManager.SecurityProtocol &= ~SecurityProtocolType.Tls;
            ServicePointManager.SecurityProtocol &= ~SecurityProtocolType.Tls11;
            // Add TLS 1.2
            ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

            string toolStatus;// = toolStatusApi("RoDo", "1.0");
            toolStatus = "Active";

            if (toolStatus == "Active")
            {
                InitializeComponent();
            }
            else
            {
                MessageBox.Show(new Form() { TopMost = true }, "Please reach out to India HRSSC Automation Team.", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Environment.Exit(0);
            }
        }

        private void btn_Download_Click(object sender, EventArgs e)
        {
            //16th May
            this.Hide();
            PendingCIDList form = new PendingCIDList();
            form.Show();
            return;
            //RAX 6th May
            //////////AmazonUploader amazonS3 = new AmazonUploader();
            //////////string UploadedURL = amazonS3.UploadFile("C:\\Users\\rakshith.r.bhat\\Downloads\\1010101_abcd.tif", "IDC");


            ////////////////SNOWCaller sn = new SNOWCaller();
            ////////////////string Snowreturn = sn.snowreturn();





            openFileDialogMail.ShowDialog();
            if (openFileDialogMail.FileName == null || openFileDialogMail.FileName == "")
            {
                ExcellName = openFileDialogMail.FileName;
                MessageBox.Show("Process has been Cancelled.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //Confirm
            if (MessageBox.Show("Preparation done. Please confirm the information and file. \nReady to run?", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == System.Windows.Forms.DialogResult.Cancel)
            {
                return;
            }

            FileInfo excel = new FileInfo(openFileDialogMail.FileName);
            DataTable Exceldt = new DataTable();

            using (var package = new ExcelPackage(excel))
            {
                if (package.Workbook.Worksheets.Count <= 0)
                {
                    MessageBox.Show("No Records.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    var worksheet = package.Workbook.Worksheets["Sheet1"];
                    Exceldt = ConvertToDataTable(worksheet);
                    Exceldt.Columns.Add(new DataColumn("Process_Status", typeof(string)));
                    GlobalVariable.GlobalDataTable = Exceldt;
                }
            }

            //String constr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + openFileDialogMail.FileName + ";Extended Properties='Excel 12.0;HDR=YES;IMEX=1';";

            //OleDbConnection con = new OleDbConnection(constr);
            //OleDbCommand oconn = new OleDbCommand("Select * From [Sheet1$]", con);
            //con.Open();
            //OleDbDataAdapter sda = new OleDbDataAdapter(oconn);
            //DataTable data = new DataTable();
            //sda.Fill(data);
            //dataGridView1.DataSource = data;
            //GlobalVariable.GlobalDataTable = data;
            //data.Columns.Add(new DataColumn("Process_Status", typeof(string)));
            //con.Close();

            btnLogin.Enabled = false;

            this.WindowState = FormWindowState.Minimized;
            Operation.ExecuteOperation();
            this.WindowState = FormWindowState.Normal;
            Excel();
            btnLogin.Enabled = true;
            MessageBox.Show("Automation process completed.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        public void Excel()
        {
            try
            {
                if (GlobalVariable.GlobalDataTable.Rows.Count > 0)
                {
                    Microsoft.Office.Interop.Excel.Application xlApp;
                    Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
                    Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
                    object misValue = System.Reflection.Missing.Value;

                    Int16 i, j;

                    xlApp = new Microsoft.Office.Interop.Excel.Application();
                    xlWorkBook = xlApp.Workbooks.Add(misValue);

                    xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                    for (int k = 1; k < GlobalVariable.GlobalDataTable.Columns.Count + 1; k++)
                    {
                        xlWorkSheet.Cells[1, k] = GlobalVariable.GlobalDataTable.Columns[k - 1].ColumnName;
                    }
                    for (i = 0; i <= GlobalVariable.GlobalDataTable.Rows.Count - 1; i++)
                    {
                        for (j = 0; j <= GlobalVariable.GlobalDataTable.Columns.Count - 1; j++)
                        {
                            xlWorkSheet.Cells[i + 2, j + 1] = GlobalVariable.GlobalDataTable.Rows[i][j].ToString();
                        }
                    }

                    string fileName = "RoDo_Download_Doc_Result_" + DateTime.Now.ToString("dd.MM.yy_HH.mm.ss") + ".xlsx";
                    xlWorkBook.SaveAs(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\" + fileName, Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                    xlWorkBook.Close(true, misValue, misValue);
                    xlApp.Quit();
                    releaseObject(xlWorkSheet);
                    releaseObject(xlWorkBook);
                    releaseObject(xlApp);

                    MessageBox.Show("Excel File is Downloaded to your Desktop. File Name is:" + fileName);
                }
            }
            catch { }
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (System.Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            btnLogin.Enabled = false;

            this.WindowState = FormWindowState.Minimized;
            Operation.Rearrange_Docs();
            this.WindowState = FormWindowState.Normal;

            btnLogin.Enabled = true;
            MessageBox.Show("Automation process completed for Rearrange docs.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void btn_Merge_Click(object sender, EventArgs e)
        {
            btnLogin.Enabled = false;

            this.WindowState = FormWindowState.Minimized;
            Operation.Merge_Docs();
            this.WindowState = FormWindowState.Normal;

            btnLogin.Enabled = true;
            MessageBox.Show("Automation process completed for Merge docs.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void btn_Convert_Click(object sender, EventArgs e)
        {
            btnLogin.Enabled = false;

            this.WindowState = FormWindowState.Minimized;
            Operation.Convert_Tiff();
            this.WindowState = FormWindowState.Normal;

            btnLogin.Enabled = true;
            MessageBox.Show("Automation process completed for Convert Tiff.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            Close();
            Environment.Exit(0);
        }

        private void btn_Minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Login_Load(object sender, EventArgs e)
        {
            btn_Download.Focus();
        }

        public static string toolStatusApi(string Tool_Name, string Tool_Version)
        {
            var request = (HttpWebRequest)WebRequest.Create("https://ssautomation.accenture.com/Automation_Tool_Status/api/values");
            var postData = "Tool_Name=" + Tool_Name + "&Tool_Version=" + Tool_Version;
            var data = Encoding.ASCII.GetBytes(postData);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("x-api-key", "BACADBBA-7B35-48D0-A601-2C85C2C6F8C9");
            request.ContentLength = data.Length;
            using (var stream = request.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }
            var response = (HttpWebResponse)request.GetResponse();
            var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
            string status = responseString.ToString();
            status = status.Remove(0, 27);
            status = status.Substring(0, status.Length - 2);
            return status;
        }

        private DataTable ConvertToDataTable(ExcelWorksheet oSheet)
        {
            int totalRows = oSheet.Dimension.End.Row;
            int totalCols = oSheet.Dimension.End.Column;
            DataTable dt = new DataTable(oSheet.Name);
            DataRow dr = null;
            try
            {
                for (int i = 1; i <= totalRows; i++)
                {
                    if (i > 1)
                        dr = dt.Rows.Add();
                    for (int j = 1; j <= totalCols; j++)
                    {
                        if (i == 1)
                            dt.Columns.Add(oSheet.Cells[i, j].Value.ToString());
                        else
                        {
                            if (oSheet.Cells[i, j].Value == null)
                            {
                                continue;
                            }
                            else
                            {
                                dr[j - 1] = oSheet.Cells[i, j].Value.ToString();
                            }
                        }

                    }
                }
            }
            catch (Exception exp)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("<script language='javascript'>");
                string sMsg = exp.Message;
                sb.Append(@"alert( """ + sMsg + @""" );");
                sb.Append(@"</script>");
                HttpContext.Current.Response.Write(sb.ToString());
            }
            return dt;
        }

    }
}
